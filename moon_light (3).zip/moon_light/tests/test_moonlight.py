"""Pruebas de Moon Light.

Cubren lo que de verdad puede romperse:
  * configuración y validación de parámetros,
  * enrutado de materias (incluida la caída al tutor general),
  * conversión de unidades (incluidas temperaturas afines e incompatibles),
  * cálculo simbólico sin `eval`,
  * agente en modo local y con un modelo simulado,
  * el servidor HTTP (se construye y se consulta sin dejarlo escuchando).

No hay ninguna llamada de red real: el cliente del modelo siempre se sustituye
por un doble de prueba.
"""

from __future__ import annotations

import json
import multiprocessing
import signal
import sys
import threading
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from moonlight import (  # noqa: E402
    AgenteMoonLight,
    Config,
    ErrorConfig,
    MATERIAS,
    Mensaje,
    RespuestaLLM,
    enrutar,
    resolver_materia,
)
from moonlight.llm import ClienteLLM, ErrorAutenticacion, ErrorCuota, ErrorRespuesta  # noqa: E402
from moonlight.tools import math_tool, units_tool  # noqa: E402

sympy_requerido = pytest.mark.skipif(
    not math_tool.esta_disponible(), reason="SymPy no está instalado"
)


# --------------------------------------------------------------- utilidades

class ClienteFalso(ClienteLLM):
    """Cliente de mentira: registra lo que se le envía y responde un texto fijo."""

    def __init__(self, config: Config | None = None, texto: str = "Explicación de prueba.",
                 error: Exception | None = None) -> None:
        super().__init__(config or Config())
        self.texto = texto
        self.error = error
        self.recibidos: list[list[Mensaje]] = []

    @property
    def disponible(self) -> bool:
        return True

    def completar(self, mensajes, temperatura=None, max_tokens=None):  # type: ignore[override]
        self.recibidos.append(list(mensajes))
        if self.error is not None:
            raise self.error
        return RespuestaLLM(texto=self.texto, modelo="falso",
                            tokens_entrada=10, tokens_salida=20)


@pytest.fixture(autouse=True)
def entorno_limpio(monkeypatch):
    """Cada prueba parte de un entorno sin variables de Moon Light."""
    for nombre in (
        "MOONLIGHT_API_KEY", "OPENAI_API_KEY", "MOONLIGHT_API_KEY_ENV",
        "MOONLIGHT_MODELO", "MOONLIGHT_BASE_URL", "MOONLIGHT_TEMPERATURA",
        "MOONLIGHT_MAX_TOKENS", "MOONLIGHT_TIMEOUT", "MOONLIGHT_REINTENTOS",
        "MOONLIGHT_MEMORIA", "MOONLIGHT_IDIOMA", "MOONLIGHT_NIVEL",
        "MOONLIGHT_LIMITE_CALCULO", "MOONLIGHT_API_TOKEN",
    ):
        monkeypatch.delenv(nombre, raising=False)


# ------------------------------------------------------------------ config

class TestConfig:
    def test_valores_por_defecto(self):
        config = Config()
        assert config.modelo
        assert config.base_url.startswith("https://")
        assert config.modo_local is True          # sin credencial en el entorno
        assert config.endpoint_chat.endswith("/chat/completions")

    def test_lee_el_entorno_al_construir_no_al_importar(self, monkeypatch):
        """El fallo clásico: leer el entorno al importar el módulo."""
        monkeypatch.setenv("MOONLIGHT_MODELO", "modelo-tardio")
        assert Config().modelo == "modelo-tardio"

    def test_credencial_detectada_y_respaldo(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_API_KEY", "  clave-1  ")
        config = Config()
        assert config.api_key == "clave-1"
        assert config.modo_local is False

        monkeypatch.delenv("MOONLIGHT_API_KEY")
        monkeypatch.setenv("OPENAI_API_KEY", "clave-respaldo")
        assert Config().api_key == "clave-respaldo"

    def test_resumen_nunca_filtra_la_clave(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_API_KEY", "secreto-super-privado")
        resumen = Config().resumen()
        assert "secreto-super-privado" not in resumen

    @pytest.mark.parametrize("cambios", [
        {"temperatura": 3.0},
        {"temperatura": -0.5},
        {"max_tokens": 8},
        {"timeout_s": 0},
        {"memoria_max_turnos": -1},
        {"limite_calculo_s": 0},
        {"base_url": "ftp://servidor/v1"},
        {"base_url": "api.openai.com/v1"},
    ])
    def test_rechaza_configuracion_invalida(self, cambios):
        with pytest.raises(ErrorConfig):
            Config().con(**cambios)

    def test_detecta_servidor_local(self):
        local = Config().con(base_url="http://localhost:11434/v1")
        assert local.es_servidor_local is True
        assert "servidor local" in local.resumen()
        assert Config().es_servidor_local is False

    def test_con_no_muta_el_original(self):
        base = Config()
        otra = base.con(nivel="primaria")
        assert otra.nivel == "primaria"
        assert base.nivel != "primaria" or base is not otra


# ----------------------------------------------------------------- materias

class TestMaterias:
    def test_catalogo_coherente(self):
        nombres = [m.nombre for m in MATERIAS]
        assert len(nombres) == len(set(nombres))
        for materia in MATERIAS:
            assert materia.palabras_clave, materia.nombre
            assert materia.plan
            assert materia.instrucciones.strip()

    def test_resolver_por_nombre_alias_y_etiqueta(self):
        assert resolver_materia("matematicas").nombre == "matematicas"
        assert resolver_materia("MATE").nombre == "matematicas"
        assert resolver_materia("Física").nombre == "fisica"
        assert resolver_materia("Arte y música").nombre == "arte"
        assert resolver_materia("quimica").nombre == "ciencias"
        assert resolver_materia("") is None
        assert resolver_materia("alquimia cuántica") is None

    def test_tolera_plurales_y_acentos(self):
        literatura = resolver_materia("literatura")
        assert literatura.puntuar("Análisis de las metáforas del poema") > 0
        assert literatura.puntuar("Sobre las novelas de Borges") > 0

    def test_las_antipalabras_restan(self):
        matematicas = resolver_materia("matematicas")
        con_anti = matematicas.puntuar("cuál es la función del narrador en la novela")
        assert con_anti == 0.0

    def test_rendimiento_decreciente(self):
        ciencias = resolver_materia("ciencias")
        una = ciencias.puntuar("que es una celula")
        varias = ciencias.puntuar("celula adn gen mitosis atomo molecula")
        assert varias > una
        assert varias < una * 6          # no crece linealmente


# ---------------------------------------------------------------- enrutador

class TestEnrutador:
    @pytest.mark.parametrize("pregunta,esperada", [
        ("deriva x^3 * sin(x)", "matematicas"),
        ("resuelve 2x^2 - 8 = 0", "matematicas"),
        ("¿qué función cumple el narrador en Pedro Páramo?", "literatura"),
        ("corrige la ortografía y la puntuación de este párrafo", "escritura"),
        ("causas de la Revolución Industrial", "historia"),
        ("explica la fotosíntesis en la célula vegetal", "ciencias"),
        ("complejidad del algoritmo de ordenación en Python", "programacion"),
        ("¿qué es una falacia según la lógica de Aristóteles?", "filosofia"),
        ("traduce 'se me hace tarde' al inglés", "idiomas"),
        ("describe el cubismo de Picasso", "arte"),
        ("¿cómo influye la cordillera en el clima?", "geografia"),
    ])
    def test_acierta_la_materia(self, pregunta, esperada):
        assert enrutar(pregunta).materia.nombre == esperada

    def test_conversion_de_unidades_va_a_fisica(self):
        decision = enrutar("convierte 72 km/h a m/s")
        assert decision.materia.nombre == "fisica"

    def test_sin_senales_cae_en_el_tutor_general(self):
        for pregunta in ("hola", "", "   ", "qué tal todo"):
            decision = enrutar(pregunta)
            assert decision.es_general
            assert decision.materia.nombre == "general"
            assert "tutor general" in decision.explicar().lower()

    def test_la_confianza_esta_normalizada(self):
        for pregunta in ("deriva x^2", "causas de la guerra fría", "hola"):
            decision = enrutar(pregunta)
            assert 0.0 <= decision.confianza <= 1.0

    def test_una_sola_candidata_da_mas_confianza_que_un_empate(self):
        sola = enrutar("deriva x^3 respecto a x")
        assert sola.materia.nombre == "matematicas"
        mezcla = enrutar("la energia del poema y la metafora de la fuerza del verso")
        assert sola.confianza > mezcla.confianza

    def test_explicar_menciona_los_motivos(self):
        decision = enrutar("calcula la derivada de x^2")
        assert decision.motivos
        assert "%" in decision.explicar()

    def test_umbral_alto_fuerza_el_general(self):
        decision = enrutar("deriva x^2 y el poema y la celula y el clima", umbral=0.99)
        assert decision.es_general


# ----------------------------------------------------------------- unidades

class TestUnidades:
    def test_velocidad(self):
        conversion = units_tool.convertir(72, "km/h", "m/s")
        assert conversion.resultado_float == pytest.approx(20.0)
        assert conversion.magnitud == "velocidad"

    def test_longitud_y_masa(self):
        assert units_tool.convertir(1, "km", "m").resultado_float == pytest.approx(1000.0)
        assert units_tool.convertir(1, "lb", "kg").resultado_float == pytest.approx(0.45359237)

    @pytest.mark.parametrize("valor,desde,hasta,esperado", [
        (100, "C", "F", 212.0),
        (32, "F", "C", 0.0),
        (0, "C", "K", 273.15),
        (300, "K", "C", 26.85),
        (0, "K", "R", 0.0),
    ])
    def test_temperatura_es_afin_no_multiplicativa(self, valor, desde, hasta, esperado):
        assert units_tool.convertir(valor, desde, hasta).resultado_float == pytest.approx(esperado)

    def test_rechaza_bajo_cero_absoluto(self):
        with pytest.raises(units_tool.ErrorUnidades):
            units_tool.convertir(-500, "C", "K")

    def test_magnitudes_incompatibles(self):
        with pytest.raises(units_tool.MagnitudIncompatible):
            units_tool.convertir(5, "kg", "m")
        with pytest.raises(units_tool.MagnitudIncompatible):
            units_tool.convertir(5, "C", "m")

    def test_unidad_desconocida(self):
        with pytest.raises(units_tool.UnidadDesconocida):
            units_tool.convertir(1, "zorgs", "m")

    def test_interpreta_lenguaje_natural(self):
        assert units_tool.interpretar("convierte 72 km/h a m/s").resultado_float == pytest.approx(20.0)
        assert units_tool.interpretar("100 °C a °F").resultado_float == pytest.approx(212.0)
        assert units_tool.interpretar("5 kg -> lb").resultado_float == pytest.approx(11.0231, rel=1e-4)
        assert units_tool.interpretar("2,5 km en m").resultado_float == pytest.approx(2500.0)

    def test_sintaxis_no_reconocida(self):
        with pytest.raises(units_tool.ErrorSintaxisUnidades):
            units_tool.interpretar("convierte algo en otra cosa")

    def test_parece_conversion(self):
        assert units_tool.parece_conversion("72 km/h a m/s") is True
        assert units_tool.parece_conversion("100 C a F") is True
        assert units_tool.parece_conversion("¿quién escribió el Quijote?") is False
        assert units_tool.parece_conversion("5 zorgs a blergs") is False

    def test_catalogo_de_unidades(self):
        catalogo = units_tool.unidades_conocidas()
        assert "temperatura" in catalogo
        assert "velocidad" in catalogo
        assert "km/h" in catalogo["velocidad"]

    def test_formato_legible(self):
        texto = units_tool.convertir(72, "km/h", "m/s").formato()
        assert "72" in texto and "20" in texto
        assert "0.000000" not in texto


# ------------------------------------------------------------ matemáticas

class TestDeteccion:
    @pytest.mark.parametrize("texto,operacion", [
        ("deriva x^2", "derivada"),
        ("calcula la derivada de x^2", "derivada"),      # el verbo específico gana
        ("integra x^2 dx", "integral"),
        ("límite de sin(x)/x cuando x -> 0", "limite"),
        ("resuelve x^2 - 4 = 0", "ecuacion"),
        ("factoriza x^2 - 9", "factorizar"),
        ("expande (x+1)^2", "expandir"),
        ("simplifica (x^2-1)/(x-1)", "simplificar"),
        ("cuánto es 2+2", "evaluar"),
    ])
    def test_detecta_la_operacion(self, texto, operacion):
        assert math_tool.detectar_operacion(texto) == operacion

    def test_sin_operacion(self):
        assert math_tool.detectar_operacion("¿quién pintó el Guernica?") is None

    def test_extrae_la_expresion(self):
        assert "x" in math_tool.extraer_expresion("deriva x^3 respecto a x")
        assert math_tool.extraer_expresion("resuelve 2x + 4 = 10").replace(" ", "") == "2x+4=10"

    def test_detecta_la_variable(self):
        assert math_tool.detectar_variable("deriva t^2 respecto a t", "t^2") == "t"
        assert math_tool.detectar_variable("deriva x^2", "x^2") == "x"


@sympy_requerido
class TestCalculo:
    def test_derivada(self):
        resultado = math_tool.calcular("deriva x^3")
        assert resultado.operacion == "derivada"
        assert "3" in resultado.salida and "x" in resultado.salida

    def test_integral(self):
        resultado = math_tool.calcular("integra x^2")
        assert resultado.operacion == "integral"
        assert "3" in resultado.salida

    def test_ecuacion_cuadratica(self):
        resultado = math_tool.calcular("resuelve x^2 - 4 = 0")
        assert resultado.operacion == "ecuacion"
        assert "2" in resultado.salida and "-2" in resultado.salida

    def test_factorizar_y_expandir(self):
        assert "(" in math_tool.calcular("factoriza x^2 - 9").salida
        expandida = math_tool.calcular("expande (x+1)^2").salida.replace(" ", "")
        assert "x**2" in expandida

    def test_limite(self):
        resultado = math_tool.calcular("límite de sin(x)/x cuando x -> 0")
        assert resultado.operacion == "limite"
        assert resultado.salida.strip() == "1"

    def test_limite_al_infinito(self):
        resultado = math_tool.calcular("limite de 1/x cuando x -> inf")
        assert resultado.salida.strip() == "0"

    def test_multiplicacion_implicita_y_potencia_con_acento_circunflejo(self):
        resultado = math_tool.calcular("deriva 2x^2")
        assert "4" in resultado.salida

    def test_no_ejecuta_codigo_del_usuario(self):
        """La prueba clave de seguridad: nada de `eval`."""
        peligrosos = [
            "simplifica __import__('os').system('echo herido')",
            "simplifica open('/etc/passwd').read()",
            "calcula ().__class__.__bases__[0].__subclasses__()",
            "simplifica exec('x=1')",
        ]
        for entrada in peligrosos:
            with pytest.raises(math_tool.ErrorCalculo):
                math_tool.calcular(entrada)

    def test_expresion_ilegible(self):
        with pytest.raises(math_tool.ErrorCalculo):
            math_tool.calcular("simplifica ((((")

    def test_formato_incluye_pasos(self):
        texto = math_tool.calcular("deriva x^3").formato()
        assert "[derivada]" in texto
        assert "·" in texto

    def test_limite_de_tiempo_configurable(self):
        # No debe fallar con un límite generoso; solo comprueba que el parámetro llega.
        assert math_tool.calcular("deriva x^2", limite_s=30).salida


# ------------------------------------------------------- límite de tiempo

# Expresión que SymPy no resuelve rápido: sirve para provocar el plazo.
EXPRESION_LENTA = "integra sin(x**3)*exp(x**2)*log(x)"


def _en_hilo(funcion, espera=60):
    """Ejecuta `funcion` en un hilo secundario y devuelve (valor, error, vivo).

    Los hilos secundarios son el caso de la API HTTP: allí no se pueden
    instalar señales, así que el motor debe recurrir al proceso aislado.
    """
    caja: dict[str, object] = {}

    def cuerpo():
        try:
            caja["valor"] = funcion()
        except BaseException as exc:  # noqa: BLE001 - se inspecciona fuera
            caja["error"] = exc

    hilo = threading.Thread(target=cuerpo)
    hilo.start()
    hilo.join(espera)
    return caja.get("valor"), caja.get("error"), hilo.is_alive()


@sympy_requerido
class TestLimiteDeTiempo:
    def test_senal_disponible_en_hilo_principal(self):
        assert math_tool._puede_usar_senal() is hasattr(signal, "SIGALRM")

    def test_sin_senal_en_hilo_secundario(self):
        valor, error, _ = _en_hilo(math_tool._puede_usar_senal, espera=5)
        assert error is None
        assert valor is False

    def test_corta_de_verdad_en_el_hilo_principal(self):
        inicio = time.monotonic()
        with pytest.raises(math_tool.ErrorTiempo):
            math_tool.calcular(EXPRESION_LENTA, limite_s=2)
        assert time.monotonic() - inicio < 10

    def test_corta_de_verdad_en_un_hilo_secundario(self):
        """El agujero que tapa esta versión: la API atiende en hilos."""
        inicio = time.monotonic()
        valor, error, vivo = _en_hilo(
            lambda: math_tool.calcular(EXPRESION_LENTA, limite_s=2)
        )
        assert not vivo, "el hilo se quedó colgado: el plazo no se respetó"
        assert valor is None
        assert isinstance(error, math_tool.ErrorTiempo)
        assert time.monotonic() - inicio < 40

    def test_resultado_correcto_desde_un_hilo_secundario(self):
        valor, error, vivo = _en_hilo(
            lambda: math_tool.calcular("deriva x^3", limite_s=20)
        )
        assert (error, vivo) == (None, False)
        assert valor.operacion == "derivada"
        assert valor.salida.replace(" ", "") == "3*x**2"
        assert valor.latex  # el LaTeX sobrevive al viaje entre procesos

    def test_el_tipo_de_error_sobrevive_al_proceso_aislado(self):
        _, error, _ = _en_hilo(
            lambda: math_tool.calcular("simplifica ((((", limite_s=20)
        )
        assert isinstance(error, math_tool.ErrorSintaxis)

    def test_sigue_sin_ejecutar_codigo_en_el_proceso_aislado(self):
        _, error, _ = _en_hilo(
            lambda: math_tool.calcular(
                "simplifica __import__('os').system('echo herido')", limite_s=20
            )
        )
        assert isinstance(error, math_tool.ErrorCalculo)

    def test_varios_hilos_a_la_vez_terminan_todos(self):
        """Con concurrencia no debe quedar ningún hilo ni proceso suelto."""
        salida: list[object] = [None] * 6

        def cuerpo(indice: int):
            texto = "deriva x^3" if indice % 2 == 0 else EXPRESION_LENTA
            try:
                salida[indice] = math_tool.calcular(texto, limite_s=2).operacion
            except math_tool.ErrorCalculo as exc:
                salida[indice] = type(exc).__name__

        hilos = [threading.Thread(target=cuerpo, args=(i,)) for i in range(6)]
        for hilo in hilos:
            hilo.start()
        for hilo in hilos:
            hilo.join(60)
        assert not any(hilo.is_alive() for hilo in hilos)
        assert salida[0] == salida[2] == salida[4] == "derivada"
        assert salida[1] == salida[3] == salida[5] == "ErrorTiempo"
        assert multiprocessing.active_children() == []

    def test_limite_cero_desactiva_el_plazo(self):
        assert math_tool.calcular("deriva x^2", limite_s=0).salida

    def test_sin_proceso_utilizable_calcula_aqui_mismo(self, monkeypatch):
        """Si el entorno no deja crear procesos, se responde en vez de fallar."""
        monkeypatch.setattr(math_tool, "_contexto_proceso", lambda: None)
        valor, error, _ = _en_hilo(
            lambda: math_tool.calcular("deriva x^3", limite_s=20)
        )
        assert error is None
        assert valor.salida.replace(" ", "") == "3*x**2"

    def test_el_contexto_se_sondea_una_sola_vez(self):
        primero = math_tool._contexto_proceso()
        assert math_tool._contexto_proceso() is primero


class TestTopeDeProcesos:
    def test_valor_por_defecto_acotado(self, monkeypatch):
        monkeypatch.delenv("MOONLIGHT_MAX_PROCESOS_CALCULO", raising=False)
        assert 2 <= math_tool._tope_procesos() <= 8

    def test_se_puede_configurar(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_MAX_PROCESOS_CALCULO", "3")
        assert math_tool._tope_procesos() == 3

    @pytest.mark.parametrize("crudo", ["", "   ", "0", "-4", "muchos", "2.5"])
    def test_valores_absurdos_caen_al_defecto(self, monkeypatch, crudo):
        monkeypatch.setenv("MOONLIGHT_MAX_PROCESOS_CALCULO", crudo)
        assert 2 <= math_tool._tope_procesos() <= 8

    def test_el_tope_frena_el_exceso_de_calculos(self, monkeypatch):
        """Con el cupo lleno se responde con un error claro, no se encola sin fin."""
        monkeypatch.setattr(
            math_tool, "_SEMAFORO_PROCESOS", threading.BoundedSemaphore(1)
        )
        # Un contexto de pega basta: el semáforo corta antes de usarlo.
        monkeypatch.setattr(math_tool, "_contexto_proceso", lambda: object())
        math_tool._SEMAFORO_PROCESOS.acquire()
        with pytest.raises(math_tool.ErrorTiempo, match="demasiados"):
            math_tool._calcular_en_proceso("deriva x^2", 0.2)


# -------------------------------------------------------------------- LLM

class TestClienteLLM:
    def test_no_disponible_sin_credencial(self):
        assert ClienteLLM(Config()).disponible is False

    def test_disponible_con_servidor_local_sin_credencial(self):
        cliente = ClienteLLM(Config().con(base_url="http://localhost:11434/v1"))
        assert cliente.disponible is True

    def test_completar_sin_credencial_lanza_autenticacion(self):
        with pytest.raises(ErrorAutenticacion):
            ClienteLLM(Config()).completar([Mensaje("user", "hola")])

    def test_completar_sin_mensajes(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_API_KEY", "clave")
        with pytest.raises(ErrorRespuesta):
            ClienteLLM(Config()).completar([])

    def test_interpreta_respuesta_estandar(self):
        bruto = {
            "model": "m",
            "choices": [{"message": {"content": "  hola  "}}],
            "usage": {"prompt_tokens": 3, "completion_tokens": 4},
        }
        respuesta = ClienteLLM._interpretar(bruto)
        assert respuesta.texto == "hola"
        assert respuesta.tokens_total == 7

    def test_interpreta_contenido_por_fragmentos(self):
        bruto = {"choices": [{"message": {"content": [{"text": "a"}, {"text": "b"}]}}]}
        assert ClienteLLM._interpretar(bruto).texto == "ab"

    @pytest.mark.parametrize("bruto", [
        {},
        {"choices": []},
        {"choices": [{"message": {"content": "   "}}]},
        {"choices": ["texto suelto"]},
    ])
    def test_respuestas_invalidas(self, bruto):
        with pytest.raises(ErrorRespuesta):
            ClienteLLM._interpretar(bruto)

    def test_espera_respeta_retry_after(self):
        cliente = ClienteLLM(Config())
        assert cliente._espera(1, 5.0) == 5.0
        assert cliente._espera(1, 999.0) == 30.0     # con techo
        assert 1.0 <= cliente._espera(1, None) <= 1.5
        assert cliente._espera(5, None) <= 16.0

    def test_reintenta_solo_los_errores_transitorios(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_API_KEY", "clave")
        monkeypatch.setattr("time.sleep", lambda _s: None)
        cliente = ClienteLLM(Config().con(max_reintentos=2))
        intentos = {"n": 0}

        def falla_dos_veces(_datos, _cabeceras):
            intentos["n"] += 1
            if intentos["n"] < 3:
                raise ErrorCuota("congestion")
            return {"choices": [{"message": {"content": "por fin"}}]}

        monkeypatch.setattr(cliente, "_peticion", falla_dos_veces)
        assert cliente.completar([Mensaje("user", "hola")]).texto == "por fin"
        assert intentos["n"] == 3

    def test_no_reintenta_errores_definitivos(self, monkeypatch):
        monkeypatch.setenv("MOONLIGHT_API_KEY", "clave")
        cliente = ClienteLLM(Config().con(max_reintentos=3))
        intentos = {"n": 0}

        def siempre_401(_datos, _cabeceras):
            intentos["n"] += 1
            raise ErrorAutenticacion("credencial inválida")

        monkeypatch.setattr(cliente, "_peticion", siempre_401)
        with pytest.raises(ErrorAutenticacion):
            cliente.completar([Mensaje("user", "hola")])
        assert intentos["n"] == 1


# ------------------------------------------------------------------ agente

class TestAgente:
    def test_pregunta_vacia(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("   ")
        assert respuesta.origen == "local"
        assert "pregunta" in respuesta.texto.lower()

    def test_modo_local_avisa_de_la_credencial(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("causas de la Revolución Francesa")
        assert respuesta.origen == "local"
        assert respuesta.materia == "historia"
        assert "modo local" in respuesta.texto
        assert "MOONLIGHT_API_KEY" in respuesta.texto

    def test_modo_local_sigue_convirtiendo_unidades(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("convierte 72 km/h a m/s")
        assert "20" in respuesta.texto
        assert "unidades" in respuesta.herramientas

    @sympy_requerido
    def test_modo_local_sigue_calculando(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("deriva x^3")
        assert any(h.startswith("matematicas") for h in respuesta.herramientas)
        assert "3" in respuesta.texto

    def test_materia_forzada(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("habla del tiempo", materia_forzada="geografia")
        assert respuesta.materia == "geografia"
        assert respuesta.confianza == 1.0

    def test_materia_forzada_desconocida_cae_en_el_enrutador(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("causas de la guerra fría", materia_forzada="alquimia")
        assert respuesta.materia == "historia"

    def test_con_modelo_simulado(self):
        cliente = ClienteFalso(texto="La derivada es 3x^2.")
        agente = AgenteMoonLight(Config(), cliente=cliente)
        respuesta = agente.responder("deriva x^3")
        assert respuesta.origen == "modelo"
        assert respuesta.texto == "La derivada es 3x^2."
        assert respuesta.tokens == 30
        sistema = cliente.recibidos[0][0]
        assert sistema.rol == "system"
        assert "Moon Light" in sistema.contenido

    @sympy_requerido
    def test_el_modelo_recibe_el_calculo_ya_hecho(self):
        cliente = ClienteFalso()
        agente = AgenteMoonLight(Config(), cliente=cliente)
        agente.responder("deriva x^3")
        ultimo = cliente.recibidos[0][-1]
        assert "herramientas fiables" in ultimo.contenido
        assert "3" in ultimo.contenido

    def test_fallo_del_modelo_cae_en_modo_local(self):
        cliente = ClienteFalso(error=ErrorCuota("cuota agotada"))
        agente = AgenteMoonLight(Config(), cliente=cliente)
        respuesta = agente.responder("causas de la guerra fría")
        assert respuesta.origen == "local"
        assert any("cuota" in a.lower() for a in respuesta.avisos)

    def test_credencial_rechazada_cae_en_modo_local(self):
        cliente = ClienteFalso(error=ErrorAutenticacion("401"))
        agente = AgenteMoonLight(Config(), cliente=cliente)
        respuesta = agente.responder("explica la fotosíntesis")
        assert respuesta.origen == "local"
        assert respuesta.avisos

    def test_memoria_guarda_turnos_completos(self):
        cliente = ClienteFalso()
        agente = AgenteMoonLight(Config().con(memoria_max_turnos=2), cliente=cliente)
        agente.responder("primera")
        agente.responder("segunda")
        agente.responder("tercera")
        assert len(agente.memoria) == 2
        assert agente.memoria[0].pregunta == "segunda"
        # Y en el envío, cada pregunta va con su respuesta.
        enviados = cliente.recibidos[-1]
        roles = [m.rol for m in enviados]
        assert roles.count("assistant") == 2
        assert roles[0] == "system" and roles[-1] == "user"

    def test_memoria_desactivada(self):
        agente = AgenteMoonLight(Config().con(memoria_max_turnos=0))
        agente.responder("hola")
        assert agente.memoria == []

    def test_reiniciar_vacia_la_memoria(self):
        agente = AgenteMoonLight(Config())
        agente.responder("hola")
        agente.reiniciar()
        assert agente.memoria == []

    def test_herramientas_desactivadas(self):
        agente = AgenteMoonLight(Config().con(herramientas_activas=False))
        respuesta = agente.responder("convierte 72 km/h a m/s")
        assert respuesta.herramientas == ()

    def test_aviso_de_unidades_incompatibles(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("convierte 5 kg a m")
        assert any("kg" in a for a in respuesta.avisos)

    def test_pregunta_conceptual_no_genera_avisos_de_sintaxis(self):
        """Una pregunta teórica de mates no debe ensuciar la respuesta con errores."""
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("¿qué es una derivada conceptualmente?")
        assert not any("interpretar" in a for a in respuesta.avisos)

    def test_formato_con_detalle(self):
        agente = AgenteMoonLight(Config())
        respuesta = agente.responder("deriva x^2")
        detalle = respuesta.formato(detalle=True)
        assert "materia:" in detalle and "origen:" in detalle
        assert "tiempo:" in detalle
        assert "materia:" not in respuesta.formato(detalle=False)

    def test_mide_el_tiempo(self):
        agente = AgenteMoonLight(Config())
        assert agente.responder("hola").segundos >= 0.0


# --------------------------------------------------------------------- CLI

class TestCLI:
    def test_listar_materias(self, capsys):
        from moonlight.cli import main
        assert main(["--materias"]) == 0
        salida = capsys.readouterr().out
        assert "matematicas" in salida and "geografia" in salida

    def test_listar_unidades(self, capsys):
        from moonlight.cli import main
        assert main(["--unidades"]) == 0
        assert "temperatura" in capsys.readouterr().out

    def test_mostrar_configuracion_sin_filtrar_la_clave(self, capsys, monkeypatch):
        from moonlight.cli import main
        monkeypatch.setenv("MOONLIGHT_API_KEY", "clave-secreta-xyz")
        assert main(["--config"]) == 0
        salida = capsys.readouterr().out
        assert "clave-secreta-xyz" not in salida
        assert "credencial detectada" in salida

    def test_pregunta_directa(self, capsys):
        from moonlight.cli import main
        assert main(["convierte 72 km/h a m/s"]) == 0
        assert "20" in capsys.readouterr().out

    def test_configuracion_invalida_devuelve_codigo_1(self, capsys):
        from moonlight.cli import main
        assert main(["--base-url", "ftp://malo", "hola"]) == 1
        assert "Configuración inválida" in capsys.readouterr().err

    def test_banner_alineado(self):
        from moonlight.cli import Color, banner
        lineas = banner(Config(), Color(False)).splitlines()
        anchos = {len(l) for l in lineas}
        assert len(anchos) == 1, "el marco del banner está descuadrado"


# --------------------------------------------------------------------- API

class TestAPI:
    """Se prueba el manejador sin abrir puertos: peticiones simuladas en memoria."""

    def _pedir(self, servidor, metodo, ruta, cuerpo=None, cabeceras=None):
        codigo, _, texto = self._pedir_crudo(servidor, metodo, ruta, cuerpo, cabeceras)
        datos = json.loads(texto) if texto.strip().startswith("{") else {}
        return codigo, datos

    def _pedir_crudo(self, servidor, metodo, ruta, cuerpo=None, cabeceras=None):
        """Devuelve (codigo, cabeceras, cuerpo en texto) sin interpretar el JSON."""
        import io

        clase = servidor.RequestHandlerClass
        cuerpo_bytes = b"" if cuerpo is None else json.dumps(cuerpo).encode("utf-8")
        lineas = [f"{metodo} {ruta} HTTP/1.1", "Host: prueba"]
        for nombre, valor in (cabeceras or {}).items():
            lineas.append(f"{nombre}: {valor}")
        if cuerpo is not None:
            lineas.append("Content-Type: application/json")
            lineas.append(f"Content-Length: {len(cuerpo_bytes)}")
        peticion = ("\r\n".join(lineas) + "\r\n\r\n").encode("utf-8") + cuerpo_bytes

        entrada = io.BytesIO(peticion)
        salida = io.BytesIO()

        class Falso:
            def makefile(self, modo, *_a, **_k):
                return entrada if "r" in modo else salida

            def sendall(self, datos):
                salida.write(datos)

            def close(self):
                pass

        clase(Falso(), ("127.0.0.1", 1234), servidor)
        crudo = salida.getvalue().decode("utf-8", errors="replace")
        cabecera, _, texto = crudo.partition("\r\n\r\n")
        lineas_cabecera = cabecera.split("\r\n")
        codigo = int(lineas_cabecera[0].split()[1])
        recibidas = {}
        for linea in lineas_cabecera[1:]:
            nombre, _, valor = linea.partition(":")
            recibidas.setdefault(nombre.strip().lower(), valor.strip())
        return codigo, recibidas, texto

    @staticmethod
    def _eventos(texto):
        """Parte un flujo SSE en una lista de (evento, datos)."""
        sucesos = []
        for bloque in texto.split("\n\n"):
            if not bloque.strip():
                continue
            nombre = None
            lineas = []
            for linea in bloque.split("\n"):
                if linea.startswith("event: "):
                    nombre = linea[7:]
                elif linea.startswith("data: "):
                    lineas.append(linea[6:])
            crudo = "\n".join(lineas)
            try:
                datos = json.loads(crudo)
            except json.JSONDecodeError:
                datos = crudo
            sucesos.append((nombre, datos))
        return sucesos

    def test_salud_no_exige_token(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(servidor, "GET", "/salud")
            assert codigo == 200
            assert datos["servicio"] == "Moon Light"
            assert datos["autenticacion"] == "ninguna"
        finally:
            servidor.server_close()

    def test_materias_y_unidades(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(servidor, "GET", "/materias")
            assert codigo == 200 and len(datos["materias"]) == len(MATERIAS)
            codigo, datos = self._pedir(servidor, "GET", "/unidades")
            assert codigo == 200 and "temperatura" in datos["unidades"]
        finally:
            servidor.server_close()

    def test_preguntar(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(
                servidor, "POST", "/preguntar", {"pregunta": "convierte 72 km/h a m/s"}
            )
            assert codigo == 200
            assert "20" in datos["respuesta"]
            assert datos["materia"] == "fisica"
            assert datos["origen"] == "local"
        finally:
            servidor.server_close()

    @pytest.mark.parametrize("cuerpo", [{}, {"pregunta": ""}, {"pregunta": 5}])
    def test_preguntas_invalidas(self, cuerpo):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, _ = self._pedir(servidor, "POST", "/preguntar", cuerpo)
            assert codigo == 400
        finally:
            servidor.server_close()

    def test_materia_desconocida(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, _ = self._pedir(
                servidor, "POST", "/preguntar",
                {"pregunta": "hola", "materia": "alquimia"},
            )
            assert codigo == 400
        finally:
            servidor.server_close()

    def test_ruta_inexistente(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            assert self._pedir(servidor, "GET", "/nada")[0] == 404
            assert self._pedir(servidor, "POST", "/nada", {"a": 1})[0] == 404
        finally:
            servidor.server_close()

    def test_token_obligatorio_cuando_esta_definido(self, monkeypatch):
        from moonlight.api import crear_servidor
        monkeypatch.setenv("MOONLIGHT_API_TOKEN", "secreto")
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            assert self._pedir(servidor, "GET", "/materias")[0] == 401
            assert self._pedir(
                servidor, "GET", "/materias",
                cabeceras={"Authorization": "Bearer equivocado"},
            )[0] == 401
            assert self._pedir(
                servidor, "GET", "/materias",
                cabeceras={"Authorization": "Bearer secreto"},
            )[0] == 200
            assert self._pedir(
                servidor, "GET", "/materias", cabeceras={"X-Moon-Token": "secreto"}
            )[0] == 200
        finally:
            servidor.server_close()

    def test_se_niega_a_exponerse_sin_token(self):
        from moonlight.api import crear_servidor
        with pytest.raises(ErrorConfig):
            crear_servidor("0.0.0.0", 0)

    def test_limitador_de_peticiones(self):
        from moonlight.api import Limitador
        limitador = Limitador(maximo=3, ventana=60.0)
        assert all(limitador.permite("1.2.3.4") for _ in range(3))
        assert limitador.permite("1.2.3.4") is False
        assert limitador.permite("5.6.7.8") is True     # otra IP no se ve afectada

    # ---------------------------------------------------------------- CORS

    def test_cors_desactivado_por_defecto(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            _, cabeceras, _ = self._pedir_crudo(
                servidor, "GET", "/salud", cabeceras={"Origin": "https://ejemplo.com"}
            )
            assert "access-control-allow-origin" not in cabeceras
        finally:
            servidor.server_close()

    def test_preflight_con_cors_activado(self, monkeypatch):
        from moonlight.api import crear_servidor
        monkeypatch.setenv("MOONLIGHT_CORS", "https://ejemplo.com")
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, cabeceras, _ = self._pedir_crudo(
                servidor, "OPTIONS", "/preguntar",
                cabeceras={"Origin": "https://ejemplo.com",
                           "Access-Control-Request-Method": "POST"},
            )
            assert codigo == 204
            assert cabeceras["access-control-allow-origin"] == "https://ejemplo.com"
            assert "POST" in cabeceras["access-control-allow-methods"]
            # un origen distinto no recibe permiso
            _, otras, _ = self._pedir_crudo(
                servidor, "OPTIONS", "/preguntar",
                cabeceras={"Origin": "https://intruso.com"},
            )
            assert "access-control-allow-origin" not in otras
        finally:
            servidor.server_close()

    def test_cors_comodin(self, monkeypatch):
        from moonlight.api import crear_servidor
        monkeypatch.setenv("MOONLIGHT_CORS", "*")
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            _, cabeceras, _ = self._pedir_crudo(
                servidor, "GET", "/salud", cabeceras={"Origin": "https://cualquiera.dev"}
            )
            assert cabeceras["access-control-allow-origin"] == "https://cualquiera.dev"
        finally:
            servidor.server_close()

    # ----------------------------------------------------------- streaming

    def test_preguntar_en_flujo(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, cabeceras, texto = self._pedir_crudo(
                servidor, "POST", "/preguntar",
                {"pregunta": "convierte 72 km/h a m/s", "stream": True},
            )
            assert codigo == 200
            assert cabeceras["content-type"].startswith("text/event-stream")
            sucesos = self._eventos(texto)
            nombres = [n for n, _ in sucesos]
            assert nombres[0] == "estado" and "meta" in nombres and "fin" in nombres
            assert sucesos[-1][1] == "[DONE]"
            texto_completo = "".join(
                d["texto"] for n, d in sucesos if n == "fragmento"
            )
            assert "20" in texto_completo
            metadatos = next(d for n, d in sucesos if n == "meta")
            assert metadatos["materia"] == "fisica"
            assert "respuesta" not in metadatos      # el texto va en fragmentos
        finally:
            servidor.server_close()

    def test_stream_como_texto_tambien_vale(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            _, cabeceras, _ = self._pedir_crudo(
                servidor, "POST", "/preguntar",
                {"pregunta": "deriva x^2", "stream": "true"},
            )
            assert cabeceras["content-type"].startswith("text/event-stream")
        finally:
            servidor.server_close()

    def test_fragmentar_no_pierde_texto(self):
        from moonlight.api import fragmentar
        texto = "La energía cinética es un medio de la masa por la velocidad al cuadrado."
        trozos = fragmentar(texto, 20)
        assert "".join(trozos) == texto
        assert all(trozos) and len(trozos) > 1
        assert fragmentar("") == []
        with pytest.raises(ValueError):
            fragmentar("algo", 0)

    # ------------------------------------------------- compatible OpenAI

    def test_lista_de_modelos(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(servidor, "GET", "/v1/models")
            assert codigo == 200 and datos["object"] == "list"
            identificadores = {m["id"] for m in datos["data"]}
            assert "moonlight" in identificadores
            assert "moonlight:fisica" in identificadores
            assert len(datos["data"]) == len(MATERIAS) + 1
        finally:
            servidor.server_close()

    def test_chat_completions(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(
                servidor, "POST", "/v1/chat/completions",
                {"model": "moonlight",
                 "messages": [{"role": "user", "content": "convierte 72 km/h a m/s"}]},
            )
            assert codigo == 200
            assert datos["object"] == "chat.completion"
            mensaje = datos["choices"][0]["message"]
            assert mensaje["role"] == "assistant" and "20" in mensaje["content"]
            assert datos["choices"][0]["finish_reason"] == "stop"
            assert datos["moonlight"]["materia"] == "fisica"
        finally:
            servidor.server_close()

    def test_chat_completions_en_flujo(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, cabeceras, texto = self._pedir_crudo(
                servidor, "POST", "/v1/chat/completions",
                {"messages": [{"role": "user", "content": "convierte 72 km/h a m/s"}],
                 "stream": True},
            )
            assert codigo == 200
            assert cabeceras["content-type"].startswith("text/event-stream")
            sucesos = self._eventos(texto)
            assert sucesos[-1][1] == "[DONE]"
            trozos = [d for _, d in sucesos[:-1]]
            assert all(t["object"] == "chat.completion.chunk" for t in trozos)
            assert trozos[0]["choices"][0]["delta"]["role"] == "assistant"
            assert trozos[-1]["choices"][0]["finish_reason"] == "stop"
            completo = "".join(
                t["choices"][0]["delta"].get("content", "") for t in trozos
            )
            assert "20" in completo
            identificadores = {t["id"] for t in trozos}
            assert len(identificadores) == 1     # un solo id para toda la respuesta
        finally:
            servidor.server_close()

    def test_contenido_en_partes_estilo_openai(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(
                servidor, "POST", "/v1/chat/completions",
                {"messages": [{"role": "user", "content": [
                    {"type": "text", "text": "convierte 72 km/h "},
                    {"type": "text", "text": "a m/s"},
                ]}]},
            )
            assert codigo == 200 and "20" in datos["choices"][0]["message"]["content"]
        finally:
            servidor.server_close()

    def test_materia_por_nombre_de_modelo(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(
                servidor, "POST", "/v1/chat/completions",
                {"model": "moonlight:historia",
                 "messages": [{"role": "user", "content": "cuéntame algo"}]},
            )
            assert codigo == 200 and datos["moonlight"]["materia"] == "historia"
            assert datos["model"] == "moonlight:historia"
            codigo, _ = self._pedir(
                servidor, "POST", "/v1/chat/completions",
                {"model": "moonlight:alquimia",
                 "messages": [{"role": "user", "content": "hola"}]},
            )
            assert codigo == 400
        finally:
            servidor.server_close()

    @pytest.mark.parametrize("cuerpo", [
        {},
        {"messages": []},
        {"messages": "hola"},
        {"messages": [{"content": "sin rol"}]},
        {"messages": ["no soy un objeto"]},
        {"messages": [{"role": "user", "content": "   "}]},
        {"messages": [{"role": "system", "content": "solo sistema"}]},
    ])
    def test_chat_completions_invalido(self, cuerpo):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, datos = self._pedir(servidor, "POST", "/v1/chat/completions", cuerpo)
            assert codigo == 400
            assert datos["error"]
            assert datos["error_openai"]["type"] == "invalid_request_error"
        finally:
            servidor.server_close()

    # ----------------------------------------------------------- historial

    def test_historial_llega_al_agente(self, monkeypatch):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        vistos = []

        clase = servidor.RequestHandlerClass
        original = clase._resolver

        def espia(self, pregunta, materia, historial):
            vistos.append((pregunta, materia, [(t.pregunta, t.respuesta) for t in historial]))
            return original(self, pregunta, materia, historial)

        monkeypatch.setattr(clase, "_resolver", espia, raising=False)
        try:
            codigo, _ = self._pedir(
                servidor, "POST", "/preguntar",
                {"pregunta": "¿y ahora?",
                 "historial": [{"pregunta": "hola", "respuesta": "qué tal"}]},
            )
            assert codigo == 200
            assert vistos[-1][2] == [("hola", "qué tal")]
        finally:
            servidor.server_close()

    @pytest.mark.parametrize("historial", [
        "no soy lista",
        ["no soy objeto"],
        [{"pregunta": "solo pregunta"}],
        [{"pregunta": 1, "respuesta": 2}],
    ])
    def test_historial_invalido(self, historial):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, _ = self._pedir(
                servidor, "POST", "/preguntar",
                {"pregunta": "hola", "historial": historial},
            )
            assert codigo == 400
        finally:
            servidor.server_close()

    def test_mensajes_previos_se_convierten_en_turnos(self, monkeypatch):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        vistos = []

        clase = servidor.RequestHandlerClass
        original = clase._resolver

        def espia(self, pregunta, materia, historial):
            vistos.append((pregunta, [(t.pregunta, t.respuesta) for t in historial]))
            return original(self, pregunta, materia, historial)

        monkeypatch.setattr(clase, "_resolver", espia, raising=False)
        try:
            codigo, _ = self._pedir(
                servidor, "POST", "/v1/chat/completions",
                {"messages": [
                    {"role": "system", "content": "eres un tutor"},
                    {"role": "user", "content": "hola"},
                    {"role": "assistant", "content": "qué tal"},
                    {"role": "user", "content": "deriva x^2"},
                ]},
            )
            assert codigo == 200
            pregunta, turnos = vistos[-1]
            assert pregunta == "deriva x^2"
            assert turnos == [("hola", "qué tal")]
        finally:
            servidor.server_close()

    def test_el_agente_no_se_comparte_entre_peticiones(self):
        """Cada petición arranca sin memoria heredada de la anterior."""
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            self._pedir(servidor, "POST", "/preguntar",
                        {"pregunta": "hola",
                         "historial": [{"pregunta": "a", "respuesta": "b"}]})
            almacen = servidor.RequestHandlerClass.almacen_hilo
            agente = getattr(almacen, "agente", None)
            assert agente is not None
            assert agente.memoria == []          # se reinicia al terminar
        finally:
            servidor.server_close()

    def test_x_forwarded_for_solo_si_se_confia(self, monkeypatch):
        from moonlight.api import crear_servidor
        monkeypatch.setenv("MOONLIGHT_CONFIA_PROXY", "1")
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            clase = servidor.RequestHandlerClass
            assert clase.confia_proxy is True
            clase.limitador = type(clase.limitador)(maximo=1, ventana=60.0)
            primera = self._pedir(servidor, "POST", "/preguntar",
                                  {"pregunta": "hola"},
                                  cabeceras={"X-Forwarded-For": "9.9.9.9, 10.0.0.1"})
            assert primera[0] == 200
            # misma IP declarada: agotada
            assert self._pedir(servidor, "POST", "/preguntar", {"pregunta": "hola"},
                               cabeceras={"X-Forwarded-For": "9.9.9.9"})[0] == 429
            # otra IP declarada: sigue pasando
            assert self._pedir(servidor, "POST", "/preguntar", {"pregunta": "hola"},
                               cabeceras={"X-Forwarded-For": "8.8.8.8"})[0] == 200
        finally:
            servidor.server_close()

    def test_cuerpo_demasiado_grande(self):
        from moonlight.api import crear_servidor
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            codigo, _ = self._pedir(
                servidor, "POST", "/preguntar", {"pregunta": "x" * 200_000}
            )
            assert codigo == 413
        finally:
            servidor.server_close()

    def test_json_no_valido(self):
        from moonlight.api import crear_servidor
        import io
        servidor = crear_servidor("127.0.0.1", 0)
        try:
            clase = servidor.RequestHandlerClass
            cuerpo = b"{esto no es json"
            peticion = (
                b"POST /preguntar HTTP/1.1\r\nHost: prueba\r\n"
                b"Content-Type: application/json\r\n"
                + f"Content-Length: {len(cuerpo)}\r\n\r\n".encode()
                + cuerpo
            )
            entrada, salida = io.BytesIO(peticion), io.BytesIO()

            class Falso:
                def makefile(self, modo, *_a, **_k):
                    return entrada if "r" in modo else salida

                def sendall(self, datos):
                    salida.write(datos)

                def close(self):
                    pass

            clase(Falso(), ("127.0.0.1", 1234), servidor)
            assert b" 400 " in salida.getvalue().split(b"\r\n")[0]
        finally:
            servidor.server_close()

    def test_tls_exige_certificado_con_la_clave(self):
        from moonlight.api import crear_servidor
        with pytest.raises(ErrorConfig):
            crear_servidor("127.0.0.1", 0, clave="solo.key")

    def test_certificado_ilegible_da_error_claro(self):
        from moonlight.api import crear_servidor
        with pytest.raises(ErrorConfig, match="certificado"):
            crear_servidor("127.0.0.1", 0, cert="/no/existe/cert.pem")

