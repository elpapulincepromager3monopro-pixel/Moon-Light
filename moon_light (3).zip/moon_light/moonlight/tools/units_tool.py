"""Conversor de unidades de Moon Light.

Precisión exacta con `decimal`
-----------------------------
Las conversiones ya no se calculan con `float` (IEEE 754), porque los factores
decimales (0.001, 1609.344, 1/3.6…) no son representables en binario y el error
se acumula: `7 g -> mg -> g` devolvía 7.000000000000001 y `1 l` daba
1000.0000000000001 ml.

Ahora:
  * Los factores se declaran como **cadenas** decimales exactas, y los que no
    son decimales finitos (km/h = 1000/3600 m/s) se guardan como razón
    "numerador/denominador", nunca precalculados.
  * Se multiplica primero y se divide **una sola vez** al final, con precisión
    interna alta, y el resultado se redondea a 28 cifras significativas.
    Así `72 km/h` da exactamente 20 m/s y la ida y vuelta cierra sin residuos
    siempre que el factor sea un decimal finito o una razón exacta.
  * Límite conocido: cuando el factor no tiene forma decimal finita (m/s -> km/h
    multiplica por 5/18; los grados centesimales usan π), la división final es
    periódica y el redondeo a 28 cifras deja un residuo del orden de 1e-28 en la
    ida y vuelta. Es el error del redondeo decimal declarado, no el de IEEE 754,
    y es ~1e12 veces menor que el de `float`. Con `Fraction` desaparecería, a
    costa de no poder representar π ni imprimir sin convertir.
  * Las temperaturas siguen siendo afines (a·x + b) y también en `Decimal`.

Otras características heredadas: errores tipados, validación de magnitudes
(kg -> m se rechaza con explicación) y precisión adaptativa al imprimir.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, localcontext

# Cifras usadas durante el cálculo y en el resultado final. El margen amplio
# evita que el único redondeo (la división final) contamine las cifras útiles.
PRECISION_INTERNA = 50
PRECISION_SALIDA = 28


class ErrorUnidades(Exception):
    """Base de los fallos de conversión."""


class UnidadDesconocida(ErrorUnidades):
    """La unidad no está en el catálogo."""


class MagnitudIncompatible(ErrorUnidades):
    """Se intentó convertir entre magnitudes distintas."""


class ErrorSintaxisUnidades(ErrorUnidades):
    """No se pudo leer la petición de conversión."""


def _a_decimal(valor: Decimal | int | float | str) -> Decimal:
    """Convierte la entrada a `Decimal` sin arrastrar el ruido del binario.

    Con un `float` se usa su representación corta (`str`), que es el número que
    el usuario escribió: 0.1 entra como Decimal('0.1'), no como 0.1000…00555.
    """
    if isinstance(valor, Decimal):
        return valor
    if isinstance(valor, int):
        return Decimal(valor)
    try:
        return Decimal(str(valor).strip().replace(",", "."))
    except (InvalidOperation, ValueError) as exc:
        raise ErrorSintaxisUnidades(f"'{valor}' no es un número válido.") from exc


def _redondear(valor: Decimal) -> Decimal:
    """Deja el valor en las cifras significativas de salida, ya normalizado.

    `normalize()` quita los ceros sobrantes (212.00 -> 212) y luego se recupera
    la forma sin exponente para los enteros, de modo que 7000 mg no se muestre
    como 7E+3 al inspeccionar el `Decimal` en bruto.
    """
    with localcontext() as ctx:
        ctx.prec = PRECISION_SALIDA
        limpio = (+valor).normalize()
    if limpio.as_tuple().exponent > 0:
        limpio = limpio.quantize(Decimal(1))
    return limpio


@dataclass(frozen=True)
class Conversion:
    valor: Decimal
    desde: str
    hasta: str
    resultado: Decimal
    magnitud: str
    detalle: str = ""

    @property
    def resultado_float(self) -> float:
        """Atajo para quien necesite un `float` (gráficas, JSON, comparaciones)."""
        return float(self.resultado)

    def formato(self) -> str:
        base = f"{_num(self.valor)} {self.desde} = {_num(self.resultado)} {self.hasta}"
        return f"{base}  ({self.magnitud}){chr(10) + '  ' + self.detalle if self.detalle else ''}"


def _num(valor: Decimal | float) -> str:
    """Formatea con la precisión justa: sin ceros de relleno ni notación absurda."""
    numero = valor if isinstance(valor, Decimal) else _a_decimal(valor)
    if numero == 0:
        return "0"
    magnitud = abs(numero)
    if magnitud >= Decimal("1e6") or magnitud < Decimal("1e-4"):
        return f"{numero:.6g}"
    texto = f"{numero:.6f}".rstrip("0").rstrip(".")
    return texto or "0"


def _normalizar_unidad(texto: str) -> str:
    """Quita acentos, grados y espacios; conserva la caja porque en unidades importa."""
    limpio = texto.strip().replace("°", "").replace("º", "")
    limpio = unicodedata.normalize("NFKD", limpio)
    return "".join(c for c in limpio if not unicodedata.combining(c)).strip()


# Factores respecto a la unidad base del SI de cada magnitud.
# Se guardan como CADENAS decimales exactas. Si el factor no es un decimal
# finito (km/h = 1000/3600 m/s), se escribe como razón "numerador/denominador"
# y la división se hace una sola vez, al final del cálculo.
FACTORES: dict[str, dict[str, str]] = {
    "longitud": {
        "m": "1", "metro": "1", "metros": "1",
        "km": "1000", "kilometro": "1000", "kilometros": "1000",
        "cm": "0.01", "centimetro": "0.01", "centimetros": "0.01",
        "mm": "0.001", "milimetro": "0.001", "milimetros": "0.001",
        "um": "1e-6", "nm": "1e-9",
        "mi": "1609.344", "milla": "1609.344", "millas": "1609.344",
        "yd": "0.9144", "yarda": "0.9144", "yardas": "0.9144",
        "ft": "0.3048", "pie": "0.3048", "pies": "0.3048",
        "in": "0.0254", "pulgada": "0.0254", "pulgadas": "0.0254",
        "nmi": "1852", "ly": "9460730472580800", "au": "149597870700",
    },
    "masa": {
        "kg": "1", "kilogramo": "1", "kilogramos": "1", "kilo": "1", "kilos": "1",
        "g": "0.001", "gramo": "0.001", "gramos": "0.001",
        "mg": "1e-6", "ug": "1e-9",
        "t": "1000", "tonelada": "1000", "toneladas": "1000",
        "lb": "0.45359237", "libra": "0.45359237", "libras": "0.45359237",
        "oz": "0.028349523125", "onza": "0.028349523125", "onzas": "0.028349523125",
    },
    "tiempo": {
        "s": "1", "seg": "1", "segundo": "1", "segundos": "1",
        "ms": "0.001", "us": "1e-6", "ns": "1e-9",
        "min": "60", "minuto": "60", "minutos": "60",
        "h": "3600", "hora": "3600", "horas": "3600",
        "dia": "86400", "dias": "86400", "d": "86400",
        "semana": "604800", "semanas": "604800",
        "anio": "31557600", "anios": "31557600", "ano": "31557600", "anos": "31557600",
    },
    "velocidad": {
        "m/s": "1", "mps": "1",
        # 1 km/h = 1000 m / 3600 s: razón exacta, no el 0.2777… truncado.
        "km/h": "1000/3600", "kmh": "1000/3600", "kph": "1000/3600",
        "mi/h": "0.44704", "mph": "0.44704",
        "kn": "1852/3600", "nudo": "1852/3600", "nudos": "1852/3600",
        "ft/s": "0.3048",
    },
    "energia": {
        "j": "1", "joule": "1", "joules": "1",
        "kj": "1000", "mj": "1e6",
        "cal": "4.184", "caloria": "4.184", "calorias": "4.184",
        "kcal": "4184",
        "wh": "3600", "kwh": "3.6e6",
        "ev": "1.602176634e-19",
        "btu": "1055.05585262",
    },
    "potencia": {
        "w": "1", "watt": "1", "watts": "1", "vatio": "1", "vatios": "1",
        "kw": "1000", "mw": "1e6",
        "hp": "745.69987158227022", "cv": "735.49875",
    },
    "presion": {
        "pa": "1", "pascal": "1", "pascales": "1",
        "kpa": "1000", "mpa": "1e6", "hpa": "100",
        "bar": "1e5", "mbar": "100",
        "atm": "101325",
        "mmhg": "133.322387415", "torr": "101325/760",
        "psi": "6894.757293168361",
    },
    "area": {
        "m2": "1", "km2": "1e6", "cm2": "1e-4", "mm2": "1e-6",
        "ha": "1e4", "hectarea": "1e4", "hectareas": "1e4",
        "acre": "4046.8564224", "acres": "4046.8564224",
        "ft2": "0.09290304", "in2": "0.00064516",
    },
    "volumen": {
        "m3": "1", "l": "0.001", "litro": "0.001", "litros": "0.001",
        "ml": "1e-6", "cl": "1e-5", "dl": "1e-4",
        "cm3": "1e-6", "cc": "1e-6",
        "gal": "0.003785411784", "galon": "0.003785411784", "galones": "0.003785411784",
        "pt": "0.000473176473", "qt": "0.000946352946",
        "ft3": "0.028316846592",
    },
    "datos": {
        "b": "1", "byte": "1", "bytes": "1",
        "kb": "1024", "mb": "1048576", "gb": "1073741824", "tb": "1099511627776",
        "bit": "0.125", "bits": "0.125",
        "kbit": "128", "mbit": "131072",
    },
    "angulo": {
        "rad": "1", "radian": "1", "radianes": "1",
        # π no es decimal exacto: estos dos factores son la mejor aproximación.
        "grad": "0.015707963267948966192313217", "gon": "0.015707963267948966192313217",
    },
}

# Grados sexagesimales: choca con °C, se resuelve por contexto en `_es_temperatura`.
_GRADOS_ANGULO = {"deg", "grado", "grados"}
_FACTOR_GRADO = "0.0174532925199432957692369077"


def _factor(expresion: str) -> tuple[Decimal, Decimal]:
    """Devuelve el factor como par (numerador, denominador) exacto."""
    if "/" in expresion:
        numerador, _, denominador = expresion.partition("/")
        return (Decimal(numerador), Decimal(denominador))
    return (Decimal(expresion), Decimal(1))


# Temperatura: conversión afín (a·x + b), no multiplicativa.
# Se define hacia kelvin y desde kelvin, siempre en Decimal.
_TEMPERATURAS: dict[str, str] = {
    "c": "C", "celsius": "C", "centigrados": "C", "centigrado": "C",
    "f": "F", "fahrenheit": "F",
    "k": "K", "kelvin": "K", "kelvins": "K",
    "r": "R", "rankine": "R",
}

_CERO_ABSOLUTO = Decimal("273.15")

_A_KELVIN = {
    "C": lambda v: v + _CERO_ABSOLUTO,
    "K": lambda v: v,
    "F": lambda v: (v - Decimal(32)) * Decimal(5) / Decimal(9) + _CERO_ABSOLUTO,
    "R": lambda v: v * Decimal(5) / Decimal(9),
}

_DESDE_KELVIN = {
    "C": lambda k: k - _CERO_ABSOLUTO,
    "K": lambda k: k,
    "F": lambda k: (k - _CERO_ABSOLUTO) * Decimal(9) / Decimal(5) + Decimal(32),
    "R": lambda k: k * Decimal(9) / Decimal(5),
}

_NOMBRE_TEMP = {"C": "°C", "F": "°F", "K": "K", "R": "°R"}


def _es_temperatura(unidad: str) -> bool:
    return _normalizar_unidad(unidad).lower() in _TEMPERATURAS


def _clave_temperatura(unidad: str) -> str:
    return _TEMPERATURAS[_normalizar_unidad(unidad).lower()]


def _buscar_magnitud(unidad: str) -> tuple[str, tuple[Decimal, Decimal]] | None:
    """Magnitud y factor (numerador, denominador) de una unidad, o None."""
    clave = _normalizar_unidad(unidad)
    minuscula = clave.lower()
    if minuscula in _GRADOS_ANGULO:
        return ("angulo", _factor(_FACTOR_GRADO))
    for magnitud, tabla in FACTORES.items():
        if minuscula in tabla:
            return (magnitud, _factor(tabla[minuscula]))
    return None


def unidades_conocidas() -> dict[str, tuple[str, ...]]:
    """Catálogo legible de lo que se puede convertir."""
    catalogo = {mag: tuple(sorted(tabla)) for mag, tabla in FACTORES.items()}
    catalogo["temperatura"] = tuple(sorted(_TEMPERATURAS))
    return catalogo


def convertir(valor: Decimal | int | float | str, desde: str, hasta: str) -> Conversion:
    """Convierte `valor` de una unidad a otra con aritmética decimal exacta.

    Acepta `int`, `float`, `str` o `Decimal`; devuelve `Decimal` para que el
    resultado no herede el ruido de IEEE 754. Lanza `UnidadDesconocida` o
    `MagnitudIncompatible` con un mensaje útil.
    """
    cantidad = _a_decimal(valor)
    temp_origen = _es_temperatura(desde)
    temp_destino = _es_temperatura(hasta)

    if temp_origen != temp_destino:
        raise MagnitudIncompatible(
            f"No se puede convertir '{desde}' a '{hasta}': una es temperatura y la otra no."
        )

    if temp_origen and temp_destino:
        origen = _clave_temperatura(desde)
        destino = _clave_temperatura(hasta)
        with localcontext() as ctx:
            ctx.prec = PRECISION_INTERNA
            kelvin = _A_KELVIN[origen](cantidad)
            if kelvin < 0:
                raise ErrorUnidades(
                    f"{_num(cantidad)} {_NOMBRE_TEMP[origen]} está por debajo del cero absoluto."
                )
            resultado = _DESDE_KELVIN[destino](kelvin)
        return Conversion(
            valor=cantidad,
            desde=_NOMBRE_TEMP[origen],
            hasta=_NOMBRE_TEMP[destino],
            resultado=_redondear(resultado),
            magnitud="temperatura",
            detalle=(
                f"Paso intermedio: {_num(_redondear(kelvin))} K "
                "(el cero absoluto es 0 K = -273.15 °C)."
            ),
        )

    info_origen = _buscar_magnitud(desde)
    info_destino = _buscar_magnitud(hasta)
    if info_origen is None:
        raise UnidadDesconocida(f"No conozco la unidad '{desde}'.")
    if info_destino is None:
        raise UnidadDesconocida(f"No conozco la unidad '{hasta}'.")

    magnitud_origen, (num_origen, den_origen) = info_origen
    magnitud_destino, (num_destino, den_destino) = info_destino
    if magnitud_origen != magnitud_destino:
        raise MagnitudIncompatible(
            f"'{desde}' mide {magnitud_origen} y '{hasta}' mide {magnitud_destino}: "
            "no son convertibles entre sí."
        )

    # valor · (n1/d1) / (n2/d2) = valor · n1 · d2 / (d1 · n2).
    # Se multiplica todo primero y se divide UNA sola vez: un único redondeo.
    with localcontext() as ctx:
        ctx.prec = PRECISION_INTERNA
        numerador = cantidad * num_origen * den_destino
        denominador = den_origen * num_destino
        resultado = numerador / denominador
        razon = (num_origen * den_destino) / denominador

    return Conversion(
        valor=cantidad,
        desde=_normalizar_unidad(desde),
        hasta=_normalizar_unidad(hasta),
        resultado=_redondear(resultado),
        magnitud=magnitud_origen,
        detalle=(
            f"Factor aplicado: 1 {_normalizar_unidad(desde)} = "
            f"{_num(_redondear(razon))} {_normalizar_unidad(hasta)}."
        ),
    )


_PATRON_CONVERSION = re.compile(
    r"(-?\d+(?:[.,]\d+)?)\s*"
    r"(°?[a-zA-Z°º]+(?:\s*/\s*[a-zA-Z]+)?|°?[a-zA-Z]+\d?)\s*"
    r"(?:a|en|to|->|→)\s*"
    r"(°?[a-zA-Z°º]+(?:\s*/\s*[a-zA-Z]+)?|°?[a-zA-Z]+\d?)",
    re.IGNORECASE,
)


def interpretar(texto: str) -> Conversion:
    """Lee una petición en lenguaje natural y la convierte.

    El número se lee directamente como `Decimal` desde el texto original, sin
    pasar por `float`, así que "2,5 km" entra como 2.5 exacto.
    Ejemplos válidos: "convierte 72 km/h a m/s", "100 C en F", "5 kg -> lb".
    """
    coincidencia = _PATRON_CONVERSION.search(texto)
    if not coincidencia:
        raise ErrorSintaxisUnidades(
            "No entendí la conversión. Escríbela como '72 km/h a m/s' o '100 °C a °F'."
        )

    bruto, desde, hasta = coincidencia.groups()
    valor = _a_decimal(bruto)  # lanza ErrorSintaxisUnidades si no es número
    return convertir(valor, desde.replace(" ", ""), hasta.replace(" ", ""))


def parece_conversion(texto: str) -> bool:
    """True si el texto parece pedir una conversión de unidades."""
    coincidencia = _PATRON_CONVERSION.search(texto)
    if not coincidencia:
        return False
    _, desde, hasta = coincidencia.groups()
    desde = desde.replace(" ", "")
    hasta = hasta.replace(" ", "")
    origen_ok = _es_temperatura(desde) or _buscar_magnitud(desde) is not None
    destino_ok = _es_temperatura(hasta) or _buscar_magnitud(hasta) is not None
    return origen_ok and destino_ok
