"""Herramientas deterministas de Moon Light.

Se exponen aquí los errores y las funciones que usa el agente, para que el
resto del paquete no dependa de la estructura interna de cada módulo.
"""

from . import math_tool, units_tool
from .math_tool import (
    ErrorCalculo,
    ErrorDependencia,
    ErrorMatematico,
    ErrorSintaxis,
    ErrorTiempo,
    Resultado,
    calcular,
    detectar_operacion,
)
from .units_tool import (
    Conversion,
    ErrorUnidades,
    MagnitudIncompatible,
    UnidadDesconocida,
    convertir,
    interpretar,
    parece_conversion,
)

__all__ = [
    "math_tool",
    "units_tool",
    "ErrorCalculo",
    "ErrorDependencia",
    "ErrorMatematico",
    "ErrorSintaxis",
    "ErrorTiempo",
    "Resultado",
    "calcular",
    "detectar_operacion",
    "Conversion",
    "ErrorUnidades",
    "MagnitudIncompatible",
    "UnidadDesconocida",
    "convertir",
    "interpretar",
    "parece_conversion",
]
