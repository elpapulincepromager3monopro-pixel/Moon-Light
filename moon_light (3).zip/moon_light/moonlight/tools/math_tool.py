"""Motor de cálculo simbólico de Moon Light.

Seguridad: **nunca** se usa `eval` ni `exec`. Se emplea `sympy.parse_expr` con
un diccionario de nombres cerrado y sin `sympify` automático de cadenas ajenas,
de forma que la entrada del usuario no puede ejecutar código Python.

Mejoras de esta versión:
  * Errores tipados (`ErrorCalculo` con subclases) en vez de `except Exception`
    genéricos: quien llama puede distinguir "no entendí la expresión" de
    "SymPy no está instalado" o "tardó demasiado".
  * La operación se detecta con patrones ancorados y ordenados por
    especificidad; "calcula" por sí solo ya no gana a "deriva".
  * Límite de tiempo real y multiplataforma para expresiones patológicas
    (ver la sección "límite de tiempo" más abajo).
  * `esta_disponible()` para que el resto del programa degrade con elegancia.
"""

from __future__ import annotations

import multiprocessing
import os
import re
import signal
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator


# --------------------------------------------------------------------- errores

class ErrorCalculo(Exception):
    """Base de los fallos del motor de cálculo."""


class ErrorDependencia(ErrorCalculo):
    """SymPy no está disponible en el entorno."""


class ErrorSintaxis(ErrorCalculo):
    """La expresión no se pudo interpretar."""


class ErrorTiempo(ErrorCalculo):
    """El cálculo excedió el tiempo permitido."""


class ErrorMatematico(ErrorCalculo):
    """La operación es válida pero no tiene solución tratable."""


# ------------------------------------------------------------------ resultado

@dataclass(frozen=True)
class Resultado:
    operacion: str
    entrada: str
    salida: str
    pasos: tuple[str, ...] = ()
    latex: str | None = None

    def formato(self) -> str:
        lineas = [f"[{self.operacion}] {self.entrada}", f"= {self.salida}"]
        lineas.extend(f"  · {p}" for p in self.pasos)
        return "\n".join(lineas)


# ------------------------------------------------------------------- límite de tiempo
#
# El objetivo es cancelar DE VERDAD un cálculo que se descontrola, en cualquier
# sistema operativo. Se usan dos niveles:
#
#   1. `SIGALRM` cuando estamos en el hilo principal de un sistema POSIX. Es
#      gratis y aborta el cálculo en el sitio.
#   2. Un proceso aparte en todos los demás casos: Windows (no tiene `SIGALRM`)
#      y los hilos secundarios (la API HTTP atiende cada petición en un hilo,
#      donde las señales no se pueden instalar). Al expirar el plazo el proceso
#      se termina, así que la CPU se libera de verdad.
#
# Un hilo con `join(timeout=...)` NO sirve aquí: `join` deja de esperar, pero
# Python no puede matar un hilo, así que el cálculo seguiría quemando CPU
# indefinidamente y cada petición dejaría un hilo zombi. Solo el sistema
# operativo puede matar una unidad de ejecución, y para eso hace falta un
# proceso.

# Margen que se concede al proceso hijo por encima de su propio plazo: primero
# intenta abortar solo (con su `SIGALRM`), que es más limpio que terminarlo.
_MARGEN_PROCESO_S = 0.5
_ESPERA_RESULTADO_S = 1.0
_ESPERA_FIN_S = 1.0
_ESPERA_SONDA_S = 10.0


def _tope_procesos() -> int:
    """Cuántos cálculos aislados pueden correr a la vez.

    Acota el consumo de recursos si llegan muchas peticiones a la API.
    """
    crudo = os.environ.get("MOONLIGHT_MAX_PROCESOS_CALCULO", "").strip()
    if crudo:
        try:
            valor = int(crudo)
        except ValueError:
            valor = 0
        if valor > 0:
            return valor
    return max(2, min(8, os.cpu_count() or 2))


_SEMAFORO_PROCESOS = threading.BoundedSemaphore(_tope_procesos())

# Contexto de multiprocessing elegido tras sondearlo (None = ninguno sirve).
_SIN_PROBAR = object()
_CONTEXTO: Any = _SIN_PROBAR
_CANDADO_CONTEXTO = threading.Lock()


def _puede_usar_senal() -> bool:
    """True si `SIGALRM` está disponible en este hilo y sistema."""
    return (
        hasattr(signal, "SIGALRM")
        and hasattr(signal, "setitimer")
        and threading.current_thread() is threading.main_thread()
    )


@contextmanager
def _limite_tiempo(segundos: float) -> Iterator[None]:
    """Aborta el bloque con `ErrorTiempo` si tarda más de `segundos`.

    Solo actúa donde `SIGALRM` es utilizable. Quien necesite garantía en
    cualquier plataforma debe pasar por `calcular()`, que además aísla el
    cálculo en un proceso cuando no hay señales.
    """
    if segundos <= 0 or not _puede_usar_senal():
        yield
        return

    def _alarma(_sig: int, _frame: object) -> None:
        raise ErrorTiempo(f"El cálculo superó los {segundos:g} s permitidos.")

    anterior = signal.signal(signal.SIGALRM, _alarma)
    signal.setitimer(signal.ITIMER_REAL, segundos)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, anterior)


def _sonda(cola: Any) -> None:
    """Cuerpo de la sonda: solo confirma que el hijo arrancó y puede responder."""
    cola.put(True)


def _probar_contexto(metodo: str) -> Any | None:
    """Devuelve el contexto `metodo` si de verdad consigue arrancar un hijo.

    `forkserver` y `spawn` reimportan el `__main__` del programa anfitrión. Si
    ese `__main__` no es importable (una sesión interactiva, código servido por
    la entrada estándar, un empaquetado raro), el hijo muere al nacer. Mejor
    descubrirlo una vez con una sonda barata que en cada cálculo.
    """
    try:
        contexto = multiprocessing.get_context(metodo)
        cola = contexto.Queue()
        proceso = contexto.Process(target=_sonda, args=(cola,), daemon=True)
        proceso.start()
        try:
            # `join` vuelve en cuanto el hijo acaba, tanto si respondió como si
            # murió al nacer: el método descartado no cuesta la espera entera.
            proceso.join(_ESPERA_SONDA_S)
            vivo = False
            if proceso.exitcode == 0:
                try:
                    vivo = cola.get(timeout=_ESPERA_RESULTADO_S) is True
                except Exception:
                    vivo = False
        finally:
            cola.cancel_join_thread()
            _detener(proceso)
            cola.close()
            proceso.join(_ESPERA_FIN_S)
            proceso.close()
        return contexto if vivo else None
    except Exception:  # noqa: BLE001 - el método simplemente no sirve aquí
        return None


def _contexto_proceso() -> Any | None:
    """Contexto de multiprocessing utilizable, o `None` si ninguno lo es.

    Orden de preferencia:
      1. `forkserver`: el servidor que engendra los hijos no tiene hilos, así
         que no hereda candados a medio tomar.
      2. `spawn`: lo único que hay en Windows.
      3. `fork`: último recurso, cuando los dos anteriores no pueden reimportar
         el `__main__` del anfitrión. Hereda el estado del proceso (con el
         riesgo conocido de candados ajenos), pero un hijo bloqueado también
         muere al vencer el plazo, así que el límite se sigue respetando.

    El resultado se memoriza: la sonda se paga una sola vez por proceso.
    """
    global _CONTEXTO
    with _CANDADO_CONTEXTO:
        if _CONTEXTO is _SIN_PROBAR:
            elegido = None
            disponibles = multiprocessing.get_all_start_methods()
            for metodo in ("forkserver", "spawn", "fork"):
                if metodo in disponibles:
                    elegido = _probar_contexto(metodo)
                    if elegido is not None:
                        break
            _CONTEXTO = elegido
        return _CONTEXTO


def _detener(proceso: Any) -> None:
    """Termina el proceso hijo sin dejarlo suelto."""
    if not proceso.is_alive():
        return
    proceso.terminate()
    proceso.join(_ESPERA_FIN_S)
    if proceso.is_alive():  # pragma: no cover - solo si ignora SIGTERM
        matar = getattr(proceso, "kill", None)
        if matar is not None:
            matar()
        proceso.join(_ESPERA_FIN_S)


def _trabajo_aislado(cola: Any, texto: str, limite_s: float) -> None:
    """Cuerpo del proceso hijo: calcula y devuelve el resultado por la cola.

    Se ejecuta en otro proceso, así que solo viaja de vuelta información
    serializable: un `Resultado` (cadenas) o un error del propio motor.
    """
    try:
        cola.put(("ok", _calcular_aqui(texto, limite_s)))
    except ErrorCalculo as exc:
        # Las subclases de ErrorCalculo llevan solo un mensaje: viajan bien.
        cola.put(("error", type(exc), str(exc)))
    except BaseException as exc:  # noqa: BLE001 - nada debe quedarse dentro
        cola.put(("error", ErrorCalculo, f"{type(exc).__name__}: {exc}"))


def _calcular_en_proceso(texto: str, limite_s: float) -> Resultado:
    """Calcula en un proceso aparte y lo mata si agota el plazo."""
    contexto = _contexto_proceso()
    if contexto is None:
        # Sin procesos utilizables no hay forma de cancelar: se calcula aquí
        # mismo. Se prefiere responder a negarse, pero conviene saberlo: en
        # ese entorno una expresión patológica puede pasarse del plazo.
        return _calcular_aqui(texto, limite_s)
    if not _SEMAFORO_PROCESOS.acquire(timeout=limite_s):
        raise ErrorTiempo(
            "Hay demasiados cálculos en curso ahora mismo; inténtalo de nuevo."
        )
    cola = contexto.Queue()
    proceso = contexto.Process(
        target=_trabajo_aislado, args=(cola, texto, limite_s), daemon=True
    )
    try:
        proceso.start()
        proceso.join(limite_s + _MARGEN_PROCESO_S)
        if proceso.is_alive():
            cola.cancel_join_thread()
            _detener(proceso)
            raise ErrorTiempo(f"El cálculo superó los {limite_s:g} s permitidos.")

        try:
            paquete = cola.get(timeout=_ESPERA_RESULTADO_S)
        except Exception as exc:  # cola vacía: el hijo murió sin responder
            raise ErrorCalculo(
                "El cálculo terminó sin devolver resultado "
                f"(código {proceso.exitcode})."
            ) from exc

        if paquete[0] == "ok":
            return paquete[1]
        _, clase, mensaje = paquete
        raise clase(mensaje)
    finally:
        _detener(proceso)
        cola.close()
        proceso.join(_ESPERA_FIN_S)
        proceso.close()
        _SEMAFORO_PROCESOS.release()


# ------------------------------------------------------------------ detección

# Orden = prioridad. Los verbos más específicos van primero para que
# "calcula la derivada de ..." se clasifique como derivada, no como evaluación.
_PATRONES_OPERACION: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("derivada", re.compile(r"\b(deriva\w*|d\s*/\s*d[a-z])\b")),
    ("integral", re.compile(r"\b(integra\w*|antiderivada|primitiva)\b|∫")),
    ("limite", re.compile(r"\b(limite|límite|lim)\b")),
    ("ecuacion", re.compile(r"\b(resuelve|resolver|despeja|despejar|soluciona|raíces|raices)\b|=")),
    ("factorizar", re.compile(r"\b(factoriza\w*|descompon\w*)\b")),
    ("expandir", re.compile(r"\b(expande|expandir|desarrolla|desarrollar)\b")),
    ("simplificar", re.compile(r"\b(simplifica\w*|reduce|reducir)\b")),
    ("evaluar", re.compile(r"\b(calcula\w*|cuanto es|cuánto es|evalúa|evalua\w*|valor de)\b")),
)

_VARIABLE = re.compile(r"\b(?:respecto\s+(?:a|de)|con\s+respecto\s+a)\s+([a-zA-Z])\b")


def detectar_operacion(texto: str) -> str | None:
    """Nombre de la operación pedida, o None si no hay indicio."""
    bajo = texto.lower()
    for nombre, patron in _PATRONES_OPERACION:
        if patron.search(bajo):
            return nombre
    return None


# --------------------------------------------------------------- extracción

# Limpia el envoltorio en lenguaje natural para dejar la expresión sola.
_RUIDO = re.compile(
    r"\b(por\s+favor|puedes|podrias|podrías|ayudame|ayúdame|necesito|quiero|"
    r"me\s+puedes|la|el|de|del|funcion|función|expresion|expresión|ecuacion|"
    r"ecuación|siguiente|para|con|respecto|a|en|paso\s+a\s+paso|resultado|"
    r"deriva\w*|integra\w*|simplifica\w*|factoriza\w*|expande|expandir|"
    r"desarrolla\w*|resuelve|resolver|despeja\w*|calcula\w*|evalúa|evalua\w*|"
    r"cuanto|cuánto|es|limite|límite|lim|valor|soluciona\w*|raices|raíces)\b",
    re.IGNORECASE,
)

_CARACTERES_VALIDOS = re.compile(r"^[0-9a-zA-Z\s\+\-\*/\^\(\)\.,=!\[\]<>_]+$")


def extraer_expresion(texto: str) -> str:
    """Aisla la parte matemática de una frase.

    Estrategia: se quitan las muletillas y se normaliza la notación corriente
    (×, ÷, comas decimales, `^`). Si tras limpiar no queda nada utilizable, se
    devuelve cadena vacía y el llamador decide.
    """
    limpio = texto.strip().rstrip("?¿.!¡")
    limpio = limpio.replace("×", "*").replace("÷", "/").replace("−", "-")
    limpio = re.sub(r"\s+", " ", limpio)

    # Si hay una igualdad, conserva los DOS lados: el izquierdo lleva la
    # incógnita y perderlo convertiría "2x + 4 = 10" en un simple "= 10".
    if "=" in limpio and not re.search(r"[<>!]=|==", limpio):
        izquierda, derecha = limpio.split("=", 1)
        izquierda = _lado_matematico(izquierda)
        derecha = _lado_matematico(derecha)
        if izquierda and derecha:
            return f"{izquierda} = {derecha}"

    sin_ruido = _RUIDO.sub(" ", limpio)
    sin_ruido = re.sub(r"\s+", " ", sin_ruido).strip()
    if not sin_ruido:
        return ""
    if not _CARACTERES_VALIDOS.match(sin_ruido):
        # Todavía hay palabras: intenta el fragmento más matemático.
        piezas = re.findall(r"[0-9a-zA-Z\.\(\)\^\*/\+\-]{2,}", sin_ruido)
        if not piezas:
            return ""
        sin_ruido = max(piezas, key=len)
    return sin_ruido.strip()


def _lado_matematico(trozo: str) -> str:
    """Deja un lado de la igualdad en notación matemática limpia, o vacío."""
    sin_ruido = re.sub(r"\s+", " ", _RUIDO.sub(" ", trozo)).strip()
    if not sin_ruido or not _CARACTERES_VALIDOS.match(sin_ruido):
        return ""
    return sin_ruido


def detectar_variable(texto: str, expresion: str) -> str:
    """Variable de trabajo: la que diga el usuario, o la más razonable de la expresión."""
    explicita = _VARIABLE.search(texto)
    if explicita:
        return explicita.group(1)
    simbolos = sorted(set(re.findall(r"(?<![a-zA-Z])([a-zA-Z])(?![a-zA-Z])", expresion)))
    for preferida in ("x", "y", "t", "n", "z"):
        if preferida in simbolos:
            return preferida
    return simbolos[0] if simbolos else "x"


# --------------------------------------------------------------------- motor

def esta_disponible() -> bool:
    """True si SymPy se puede importar; permite degradar sin romper nada."""
    try:
        import sympy  # noqa: F401
    except ImportError:
        return False
    return True


def _entorno_seguro() -> dict[str, object]:
    """Nombres permitidos al interpretar la expresión. Todo lo demás se rechaza."""
    import sympy as sp

    permitido: dict[str, object] = {
        "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
        "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
        "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh,
        "exp": sp.exp, "log": sp.log, "ln": sp.log, "sqrt": sp.sqrt,
        "Abs": sp.Abs, "abs": sp.Abs, "factorial": sp.factorial,
        "pi": sp.pi, "E": sp.E, "e": sp.E, "oo": sp.oo, "inf": sp.oo, "I": sp.I,
    }
    for nombre in "abcdfghkmnpqrstuvwxyz":
        permitido.setdefault(nombre, sp.Symbol(nombre))
    permitido["x"] = sp.Symbol("x")
    return permitido


def _entorno_global() -> dict[str, object]:
    """Nombres mínimos que necesitan las transformaciones de SymPy.

    `parse_expr` reescribe la entrada antes de evaluarla: los números pasan a
    `Integer(...)`/`Float(...)` y los nombres sueltos a `Symbol(...)`. Esos
    constructores tienen que existir, pero nada más: así la expresión del
    usuario no alcanza el espacio global de SymPy ni el de Python.
    """
    import sympy as sp

    return {
        "Integer": sp.Integer,
        "Float": sp.Float,
        "Rational": sp.Rational,
        "Symbol": sp.Symbol,
        "Function": sp.Function,
    }


def _parsear(expresion: str):
    """Convierte texto en expresión de SymPy sin ejecutar código del usuario."""
    import tokenize
    try:
        from sympy.parsing.sympy_parser import (
            convert_xor,
            implicit_multiplication_application,
            parse_expr,
            standard_transformations,
        )
    except ImportError as exc:  # pragma: no cover - entorno sin SymPy
        raise ErrorDependencia(
            "SymPy no está instalado: no puedo hacer cálculo simbólico. "
            "Instálalo con 'pip install sympy'."
        ) from exc

    if not expresion or not expresion.strip():
        raise ErrorSintaxis("No encontré una expresión matemática en la pregunta.")

    transformaciones = standard_transformations + (
        convert_xor,                               # ^ como potencia
        implicit_multiplication_application,       # 2x -> 2*x
    )
    try:
        return parse_expr(
            expresion,
            local_dict=_entorno_seguro(),
            transformations=transformaciones,
            evaluate=True,
            global_dict=_entorno_global(),   # solo los constructores imprescindibles
        )
    except ErrorCalculo:
        raise
    except (SyntaxError, TypeError, ValueError, AttributeError, KeyError,
            tokenize.TokenError, RecursionError) as exc:
        # `tokenize.TokenError` aparece con paréntesis sin cerrar, p. ej. "((((".
        raise ErrorSintaxis(f"No pude interpretar '{expresion}': {exc}") from exc


def calcular(texto: str, limite_s: float = 8.0) -> Resultado:
    """Resuelve la petición matemática contenida en `texto`.

    El plazo de `limite_s` se respeta en cualquier sistema operativo: si las
    señales no están disponibles (Windows, o un hilo secundario como los que
    usa la API HTTP) el cálculo se aísla en un proceso que se termina al
    expirar el plazo.

    Lanza una subclase de `ErrorCalculo` describiendo con precisión qué falló.
    """
    if not esta_disponible():
        raise ErrorDependencia(
            "SymPy no está instalado: no puedo hacer cálculo simbólico. "
            "Instálalo con 'pip install sympy'."
        )
    if limite_s > 0 and not _puede_usar_senal():
        return _calcular_en_proceso(texto, limite_s)
    return _calcular_aqui(texto, limite_s)


def _calcular_aqui(texto: str, limite_s: float) -> Resultado:
    """Resuelve la petición en el proceso actual."""
    if not esta_disponible():
        raise ErrorDependencia(
            "SymPy no está instalado: no puedo hacer cálculo simbólico. "
            "Instálalo con 'pip install sympy'."
        )

    import sympy as sp

    operacion = detectar_operacion(texto) or "simplificar"

    if operacion == "limite":
        return _limite(texto, limite_s)

    expresion_txt = extraer_expresion(texto)
    if not expresion_txt:
        raise ErrorSintaxis("No encontré una expresión matemática en la pregunta.")

    variable_txt = detectar_variable(texto, expresion_txt)

    with _limite_tiempo(limite_s):
        var = sp.Symbol(variable_txt)

        if operacion == "ecuacion":
            return _ecuacion(expresion_txt, var)

        expr = _parsear(expresion_txt)
        try:
            if operacion == "derivada":
                resultado = sp.diff(expr, var)
                pasos = (
                    f"Derivamos respecto a {var}.",
                    f"Forma simplificada: {sp.simplify(resultado)}",
                )
            elif operacion == "integral":
                resultado = sp.integrate(expr, var)
                if resultado.has(sp.Integral):
                    raise ErrorMatematico(
                        f"La integral de {expr} no tiene primitiva elemental conocida."
                    )
                pasos = (
                    f"Integramos respecto a {var}.",
                    "No olvides la constante + C en la integral indefinida.",
                )
            elif operacion == "factorizar":
                resultado = sp.factor(expr)
                pasos = (f"Expandida sería: {sp.expand(expr)}",)
            elif operacion == "expandir":
                resultado = sp.expand(expr)
                pasos = (f"Factorizada sería: {sp.factor(expr)}",)
            elif operacion == "evaluar":
                simplificada = sp.simplify(expr)
                if simplificada.free_symbols:
                    resultado = simplificada
                    pasos = (
                        "Quedan variables libres: "
                        f"{', '.join(sorted(str(s) for s in simplificada.free_symbols))}.",
                    )
                else:
                    resultado = simplificada
                    valor = sp.N(simplificada, 10)
                    pasos = (f"Valor numérico ≈ {valor}",)
            else:  # simplificar
                resultado = sp.simplify(expr)
                pasos = (f"Expresión original: {expr}",)
        except ErrorCalculo:
            raise
        except (sp.SympifyError, TypeError, ValueError, NotImplementedError) as exc:
            raise ErrorMatematico(f"No pude completar la operación: {exc}") from exc
        except RecursionError as exc:
            raise ErrorMatematico("La expresión es demasiado compleja.") from exc

    return Resultado(
        operacion=operacion,
        entrada=expresion_txt,
        salida=str(resultado),
        pasos=pasos,
        latex=sp.latex(resultado),
    )


def _ecuacion(expresion_txt: str, var) -> Resultado:
    import sympy as sp

    if "=" in expresion_txt:
        izq_txt, _, der_txt = expresion_txt.partition("=")
        izquierda = _parsear(izq_txt)
        derecha = _parsear(der_txt)
    else:
        izquierda = _parsear(expresion_txt)
        derecha = sp.Integer(0)

    ecuacion = sp.Eq(izquierda, derecha)
    try:
        soluciones = sp.solve(ecuacion, var, dict=False)
    except (NotImplementedError, sp.SympifyError, TypeError, ValueError) as exc:
        raise ErrorMatematico(f"No pude resolver la ecuación: {exc}") from exc

    if not soluciones:
        raise ErrorMatematico(f"La ecuación {ecuacion} no tiene solución para {var}.")

    texto_sol = ", ".join(f"{var} = {s}" for s in soluciones)
    pasos = [f"Ecuación planteada: {ecuacion}", f"Soluciones encontradas: {len(soluciones)}"]
    grado = None
    try:
        grado = sp.degree(sp.expand(izquierda - derecha), var)
    except (sp.PolynomialError, TypeError, ValueError):
        grado = None
    if grado is not None:
        pasos.append(f"Es una ecuación de grado {grado} en {var}.")

    return Resultado(
        operacion="ecuacion",
        entrada=str(ecuacion),
        salida=texto_sol,
        pasos=tuple(pasos),
        latex=sp.latex(soluciones),
    )


_PATRON_LIMITE = re.compile(
    r"(?:limite|límite|lim)\s*(?:de\s+)?(.+?)\s*(?:cuando|con|para)?\s*"
    r"([a-zA-Z])\s*(?:->|→|tiende a|tiende)\s*(-?\w+(?:\.\d+)?)",
    re.IGNORECASE,
)


def _grupos_limite(coincidencia: re.Match[str]) -> tuple[str, str, str]:
    """Extrae los tres grupos del patrón de límite (expresión, variable, punto)."""
    return coincidencia.group(1), coincidencia.group(2), coincidencia.group(3)


def _limite(texto: str, limite_s: float) -> Resultado:
    import sympy as sp

    coincidencia = _PATRON_LIMITE.search(texto)
    if not coincidencia:
        raise ErrorSintaxis(
            "Para un límite indica la expresión y el punto, "
            "por ejemplo: 'límite de sin(x)/x cuando x -> 0'."
        )

    expr_txt, var_txt, punto_txt = (g.strip() for g in _grupos_limite(coincidencia))
    expr = _parsear(expr_txt)
    var = sp.Symbol(var_txt)

    punto_bajo = punto_txt.lower()
    if punto_bajo in {"inf", "infinito", "oo", "+inf"}:
        punto = sp.oo
    elif punto_bajo in {"-inf", "-infinito", "-oo"}:
        punto = -sp.oo
    else:
        punto = _parsear(punto_txt)

    with _limite_tiempo(limite_s):
        try:
            valor = sp.limit(expr, var, punto)
        except (NotImplementedError, sp.SympifyError, TypeError, ValueError) as exc:
            raise ErrorMatematico(f"No pude calcular el límite: {exc}") from exc

    return Resultado(
        operacion="limite",
        entrada=f"lim {var}->{punto} de {expr}",
        salida=str(valor),
        pasos=(
            "Comprueba primero si hay indeterminación al sustituir.",
            "Si aparece 0/0 o ∞/∞, L'Hôpital o factorizar suelen resolverlo.",
        ),
        latex=sp.latex(valor),
    )



