"""Cliente de modelo de lenguaje para Moon Light.

Habla el dialecto "chat completions" compatible con OpenAI, así que funciona
igual con la API de OpenAI o con un servidor local (Ollama, LM Studio, vLLM,
Hermes...) cambiando solo la URL base.

Se usa solo la biblioteca estándar (`urllib`): no hay dependencias externas.

Mejoras de esta versión:
  * Excepciones tipadas por causa (autenticación, cuota, red, respuesta rara)
    en vez de una sola genérica.
  * Reintentos solo en errores transitorios, con espera exponencial y respeto
    de la cabecera `Retry-After`.
  * Registro con `logging` en lugar de prints silenciados.
  * La clave nunca se escribe en los mensajes de error ni en los registros.
"""

from __future__ import annotations

import json
import logging
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Sequence

from .config import Config

log = logging.getLogger("moonlight.llm")


class ErrorLLM(Exception):
    """Fallo al hablar con el modelo."""


class ErrorAutenticacion(ErrorLLM):
    """Credencial ausente, inválida o sin permisos."""


class ErrorCuota(ErrorLLM):
    """Cuota agotada o demasiadas peticiones."""


class ErrorRed(ErrorLLM):
    """No se pudo alcanzar el servidor."""


class ErrorRespuesta(ErrorLLM):
    """El servidor contestó algo que no se puede usar."""


class ErrorServidor(ErrorLLM):
    """El servidor falló (5xx) tras agotar los reintentos."""


@dataclass(frozen=True)
class Mensaje:
    rol: str  # "system" | "user" | "assistant"
    contenido: str

    def como_dict(self) -> dict[str, str]:
        return {"role": self.rol, "content": self.contenido}


@dataclass(frozen=True)
class RespuestaLLM:
    texto: str
    modelo: str
    tokens_entrada: int = 0
    tokens_salida: int = 0

    @property
    def tokens_total(self) -> int:
        return self.tokens_entrada + self.tokens_salida


# Códigos que merece la pena reintentar: congestión y fallos temporales.
_REINTENTABLES = {408, 409, 425, 429, 500, 502, 503, 504}


class ClienteLLM:
    """Cliente mínimo y robusto de chat completions."""

    def __init__(self, config: Config | None = None) -> None:
        self.config = config or Config()

    # ------------------------------------------------------------- público

    @property
    def disponible(self) -> bool:
        """True si hay credencial o si el destino es un servidor local."""
        return not self.config.modo_local or self.config.es_servidor_local

    def completar(
        self,
        mensajes: Sequence[Mensaje],
        temperatura: float | None = None,
        max_tokens: int | None = None,
    ) -> RespuestaLLM:
        """Envía la conversación y devuelve la respuesta del modelo."""
        if not mensajes:
            raise ErrorRespuesta("No hay mensajes que enviar.")
        if self.config.modo_local and not self.config.es_servidor_local:
            raise ErrorAutenticacion(
                f"No hay credencial en {self.config.api_key_env}. "
                "Define la variable de entorno o apunta la URL base a un modelo local."
            )

        cuerpo = {
            "model": self.config.modelo,
            "messages": [m.como_dict() for m in mensajes],
            "temperature": self.config.temperatura if temperatura is None else temperatura,
            "max_tokens": self.config.max_tokens if max_tokens is None else max_tokens,
        }
        datos = json.dumps(cuerpo, ensure_ascii=False).encode("utf-8")

        cabeceras = {
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "User-Agent": "MoonLight/2.0",
        }
        clave = self.config.api_key
        if clave:
            cabeceras["Authorization"] = f"Bearer {clave}"

        ultimo: ErrorLLM | None = None
        intentos = max(1, self.config.max_reintentos + 1)

        for intento in range(1, intentos + 1):
            try:
                bruto = self._peticion(datos, cabeceras)
                return self._interpretar(bruto)
            except (ErrorCuota, ErrorServidor, ErrorRed) as exc:
                ultimo = exc
                if intento == intentos:
                    break
                espera = self._espera(intento, getattr(exc, "retry_after", None))
                log.warning(
                    "Intento %d/%d falló (%s). Reintento en %.1f s.",
                    intento, intentos, type(exc).__name__, espera,
                )
                time.sleep(espera)
            except ErrorLLM:
                # Autenticación o respuesta inválida: reintentar no ayuda.
                raise

        assert ultimo is not None
        raise ultimo

    # -------------------------------------------------------------- interno

    @staticmethod
    def _espera(intento: int, retry_after: float | None) -> float:
        if retry_after and retry_after > 0:
            return min(30.0, retry_after)
        # Exponencial con algo de aleatoriedad para no sincronizar reintentos.
        return min(16.0, (2 ** (intento - 1)) * 1.0 + random.uniform(0, 0.4))

    def _peticion(self, datos: bytes, cabeceras: dict[str, str]) -> dict[str, Any]:
        peticion = urllib.request.Request(
            self.config.endpoint_chat, data=datos, headers=cabeceras, method="POST"
        )
        try:
            with urllib.request.urlopen(peticion, timeout=self.config.timeout_s) as resp:
                contenido = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            self._lanzar_http(exc)
            raise  # pragma: no cover - _lanzar_http siempre lanza
        except urllib.error.URLError as exc:
            raise ErrorRed(
                f"No pude conectar con el servidor del modelo: {exc.reason}. "
                "Revisa tu conexión o la URL base configurada."
            ) from exc
        except TimeoutError as exc:
            raise ErrorRed(
                f"El modelo no respondió en {self.config.timeout_s:g} s."
            ) from exc

        try:
            cargado = json.loads(contenido)
        except json.JSONDecodeError as exc:
            raise ErrorRespuesta("El servidor devolvió algo que no es JSON.") from exc
        if not isinstance(cargado, dict):
            raise ErrorRespuesta("La respuesta del servidor no tiene el formato esperado.")
        return cargado

    @staticmethod
    def _lanzar_http(exc: urllib.error.HTTPError) -> None:
        """Traduce un error HTTP a la excepción tipada correspondiente."""
        try:
            detalle_bruto = exc.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001 - el cuerpo del error es opcional
            detalle_bruto = ""

        mensaje = ""
        if detalle_bruto:
            try:
                cargado = json.loads(detalle_bruto)
                if isinstance(cargado, dict):
                    error = cargado.get("error")
                    if isinstance(error, dict):
                        mensaje = str(error.get("message", ""))
                    elif isinstance(error, str):
                        mensaje = error
            except json.JSONDecodeError:
                mensaje = detalle_bruto[:200]

        codigo = exc.code
        sufijo = f" Detalle: {mensaje}" if mensaje else ""

        if codigo in (401, 403):
            raise ErrorAutenticacion(
                f"El modelo rechazó la credencial (HTTP {codigo}).{sufijo}"
            ) from exc
        if codigo == 404:
            raise ErrorRespuesta(
                f"Ruta o modelo inexistente (HTTP 404). Comprueba el nombre del modelo.{sufijo}"
            ) from exc
        if codigo == 429:
            error = ErrorCuota(f"Demasiadas peticiones o cuota agotada.{sufijo}")
            cabecera = exc.headers.get("Retry-After") if exc.headers else None
            if cabecera:
                try:
                    error.retry_after = float(cabecera)  # type: ignore[attr-defined]
                except ValueError:
                    pass
            raise error from exc
        if 500 <= codigo < 600:
            raise ErrorServidor(f"El servidor del modelo falló (HTTP {codigo}).{sufijo}") from exc
        raise ErrorRespuesta(f"Error HTTP {codigo} al llamar al modelo.{sufijo}") from exc

    @staticmethod
    def _interpretar(bruto: dict[str, Any]) -> RespuestaLLM:
        opciones = bruto.get("choices")
        if not isinstance(opciones, list) or not opciones:
            raise ErrorRespuesta("La respuesta del modelo no contiene texto.")
        primera = opciones[0]
        if not isinstance(primera, dict):
            raise ErrorRespuesta("La respuesta del modelo tiene un formato inesperado.")

        mensaje = primera.get("message")
        texto = ""
        if isinstance(mensaje, dict):
            contenido = mensaje.get("content")
            if isinstance(contenido, str):
                texto = contenido
            elif isinstance(contenido, list):
                # Algunos servidores devuelven una lista de fragmentos.
                texto = "".join(
                    str(p.get("text", "")) for p in contenido if isinstance(p, dict)
                )
        elif isinstance(primera.get("text"), str):
            texto = primera["text"]

        texto = texto.strip()
        if not texto:
            raise ErrorRespuesta("El modelo devolvió una respuesta vacía.")

        uso = bruto.get("usage") if isinstance(bruto.get("usage"), dict) else {}
        return RespuestaLLM(
            texto=texto,
            modelo=str(bruto.get("model", "desconocido")),
            tokens_entrada=int(uso.get("prompt_tokens", 0) or 0),
            tokens_salida=int(uso.get("completion_tokens", 0) or 0),
        )
