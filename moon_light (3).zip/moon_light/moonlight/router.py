"""Enrutador de materias: decide qué especialista de Moon Light atiende cada pregunta.

Mejoras de esta versión:
  * La confianza ya no es "puntaje / suma": se calcula con un margen relativo
    entre el primero y el segundo, que es lo que de verdad indica seguridad.
    Con una única materia candidata la confianza sube; con dos empatadas, baja.
  * Si nada supera el umbral, cae en el tutor general en lugar de forzar una
    materia al azar.
  * `Decision.motivos` explica qué palabras dispararon la elección (trazabilidad).
  * Detecta señales de física (magnitud + unidad) y no solo conversiones.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .subjects import MATERIA_GENERAL, MATERIAS, Materia, normalizar
from .tools import units_tool

# Patrones que delatan una expresión matemática aunque no haya palabras clave:
# "2x^2 - 3 = 0", "d/dx sin(x)", "∫ x dx".
_SENALES_MATE = (
    re.compile(r"\d\s*[-+*/^]\s*\d"),
    re.compile(r"[a-z]\s*\^\s*\d"),
    re.compile(r"\d\s*[a-z]\s*\^"),          # 2x^2
    re.compile(r"=\s*-?\d"),                  # ... = 0
    re.compile(r"\bd\s*/\s*d[a-z]\b"),
    re.compile(r"[∫∑√π]"),
    re.compile(r"\b(sin|cos|tan|log|ln|sqrt|exp)\s*\("),
    re.compile(r"\b\d+\s*[a-z]\s*[-+]"),      # 3x - 5
)

# "72 km/h a m/s", "convierte 100 C en K": conversión de unidades.
_SENAL_UNIDADES = re.compile(
    r"-?\d+(?:[.,]\d+)?\s*°?[a-z]+(?:/[a-z]+)?\s+(?:a|en|to)\s+°?[a-z]+(?:/[a-z]+)?",
    re.IGNORECASE,
)

# Número seguido de una unidad física: "20 m/s", "5 kg", "9.8 m/s2".
_SENAL_MAGNITUD = re.compile(
    r"\b\d+(?:[.,]\d+)?\s*(km/h|m/s|km|cm|mm|kg|g|mg|ms|hz|n|j|kj|w|kw|v|a|pa|kpa|atm|bar|c|k|f)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class Decision:
    """Resultado del enrutado."""

    materia: Materia
    confianza: float
    alternativas: tuple[tuple[str, float], ...] = ()
    motivos: tuple[str, ...] = field(default_factory=tuple)

    @property
    def es_ambigua(self) -> bool:
        """Dos materias casi empatadas: conviene una respuesta híbrida."""
        if not self.alternativas:
            return False
        return (self.confianza - self.alternativas[0][1]) < 0.20

    @property
    def es_general(self) -> bool:
        return self.materia.nombre == MATERIA_GENERAL.nombre

    def explicar(self) -> str:
        """Texto corto que justifica la elección (útil para depurar y para --detalle)."""
        if self.es_general:
            return "Sin señales claras de una materia concreta: responde el tutor general."
        base = f"{self.materia.etiqueta} ({self.confianza:.0%})"
        if self.motivos:
            base += " por: " + ", ".join(self.motivos[:4])
        if self.alternativas:
            base += " | también encaja: " + ", ".join(
                f"{n} {p:.0%}" for n, p in self.alternativas[:2]
            )
        return base


def _senales_mate(pregunta: str) -> float:
    texto = normalizar(pregunta)
    # Se saturan en 3 para que la notación no aplaste al léxico.
    return min(3.0, sum(1.0 for patron in _SENALES_MATE if patron.search(texto)))


def _senal_unidades(pregunta: str) -> float:
    """Solo cuenta si ambas unidades existen de verdad en el catálogo.

    Sin esta comprobación, "deriva x^3 respecto a x" parecía una conversión
    ("3 respecto a x") y se iba a física en lugar de a matemáticas.
    """
    if not _SENAL_UNIDADES.search(normalizar(pregunta)):
        return 0.0
    return 2.5 if units_tool.parece_conversion(pregunta) else 0.0


def _senal_magnitud(pregunta: str) -> float:
    return 1.0 if _SENAL_MAGNITUD.search(normalizar(pregunta)) else 0.0


def enrutar(
    pregunta: str,
    materias: tuple[Materia, ...] = MATERIAS,
    umbral: float = 0.18,
) -> Decision:
    """Devuelve la materia más probable con una confianza normalizada 0-1.

    `umbral` es el puntaje mínimo (relativo al total) por debajo del cual se
    prefiere el tutor general antes que arriesgar una materia equivocada.
    """
    if not pregunta or not pregunta.strip():
        return Decision(MATERIA_GENERAL, 0.0)

    bonus_mate = _senales_mate(pregunta)
    bonus_unidades = _senal_unidades(pregunta)
    bonus_magnitud = _senal_magnitud(pregunta)

    puntajes: list[tuple[Materia, float, tuple[str, ...]]] = []
    for materia in materias:
        puntaje = materia.puntuar(pregunta)
        motivos = materia.coincidencias(pregunta)
        if materia.nombre == "matematicas" and bonus_mate:
            puntaje += bonus_mate
            motivos = motivos + ("notación matemática",)
        if materia.nombre == "fisica":
            # Convertir unidades y las magnitudes con unidad apuntan a física.
            if bonus_unidades:
                puntaje += bonus_unidades
                motivos = motivos + ("conversión de unidades",)
            elif bonus_magnitud and puntaje > 0:
                puntaje += bonus_magnitud
                motivos = motivos + ("magnitud con unidad",)
        if puntaje > 0:
            puntajes.append((materia, puntaje, motivos))

    if not puntajes:
        return Decision(MATERIA_GENERAL, 0.0)

    puntajes.sort(key=lambda t: t[1], reverse=True)
    total = sum(p for _, p, _ in puntajes)
    mejor, mejor_puntaje, motivos = puntajes[0]
    cuota = mejor_puntaje / total

    if cuota < umbral:
        return Decision(MATERIA_GENERAL, round(cuota, 3))

    # Confianza = cuota corregida por el margen sobre el segundo clasificado.
    segundo = puntajes[1][1] if len(puntajes) > 1 else 0.0
    margen = (mejor_puntaje - segundo) / mejor_puntaje  # 0 = empate, 1 = solitario
    confianza = min(1.0, 0.55 * cuota + 0.45 * margen + 0.15 * cuota * margen)

    alternativas = tuple((m.nombre, round(p / total, 3)) for m, p, _ in puntajes[1:4])
    return Decision(mejor, round(confianza, 3), alternativas, motivos)
