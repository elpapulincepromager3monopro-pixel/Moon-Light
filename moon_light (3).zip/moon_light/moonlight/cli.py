"""Interfaz de línea de comandos de Moon Light.

Modos:
  * Pregunta directa:  `moonlight "deriva x^2"`
  * Sesión interactiva: `moonlight` (sin argumentos)
  * Utilidades:        `--materias`, `--unidades`, `--config`

Mejoras de esta versión:
  * El marco del banner se calcula midiendo el texto real, así que nunca queda
    descuadrado aunque cambie el nombre o la versión.
  * Registro configurable con `-v` / `--verbose`.
  * Códigos de salida coherentes (0 correcto, 1 error de uso, 2 fallo interno,
    130 interrupción del usuario) para que sirva en scripts.
  * Detecta si la salida es un terminal antes de usar color.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import unicodedata

from .agent import AgenteMoonLight
from .config import NOMBRE, VERSION, Config, ErrorConfig
from .subjects import MATERIAS, resolver_materia
from .tools import units_tool


# ------------------------------------------------------------------- formato

def _ancho(texto: str) -> int:
    """Ancho visual del texto contando los caracteres anchos como dos columnas."""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in texto)


def _usar_color() -> bool:
    if os.getenv("NO_COLOR"):
        return False
    return sys.stdout.isatty()


class Color:
    def __init__(self, activo: bool) -> None:
        self.activo = activo

    def _pintar(self, texto: str, codigo: str) -> str:
        return f"\033[{codigo}m{texto}\033[0m" if self.activo else texto

    def titulo(self, texto: str) -> str:
        return self._pintar(texto, "1;36")

    def suave(self, texto: str) -> str:
        return self._pintar(texto, "2")

    def aviso(self, texto: str) -> str:
        return self._pintar(texto, "33")

    def error(self, texto: str) -> str:
        return self._pintar(texto, "31")


def banner(config: Config, color: Color) -> str:
    """Marco de bienvenida perfectamente alineado, calculado a partir del texto."""
    lineas = [
        f"{NOMBRE}  v{VERSION}",
        "Tutor de estudio: literatura, escritura, historia, matemáticas,",
        "física, ciencias, programación, filosofía, idiomas, arte y geografía.",
        "",
        config.resumen(),
        "",
        "Escribe tu pregunta. Comandos: /materia <nombre>, /limpiar, /ayuda, /salir",
    ]
    interior = max(_ancho(l) for l in lineas) + 2
    arriba = "╭" + "─" * interior + "╮"
    abajo = "╰" + "─" * interior + "╯"
    cuerpo = [
        "│ " + linea + " " * (interior - 1 - _ancho(linea)) + "│"
        for linea in lineas
    ]
    return color.titulo("\n".join([arriba, *cuerpo, abajo]))


# ----------------------------------------------------------------- listados

def listar_materias(color: Color) -> str:
    lineas = [color.titulo(f"Materias de {NOMBRE}"), ""]
    for materia in MATERIAS:
        marca = " [cálculo exacto]" if materia.usa_calculo else ""
        lineas.append(f"  {materia.nombre:<14} {materia.etiqueta}{marca}")
        muestra = ", ".join(materia.palabras_clave[:6])
        lineas.append(color.suave(f"                 p. ej.: {muestra}"))
    lineas.append("")
    lineas.append(color.suave("  Usa --materia <nombre> para forzar una en concreto."))
    return "\n".join(lineas)


def listar_unidades(color: Color) -> str:
    lineas = [color.titulo("Unidades que puedo convertir"), ""]
    for magnitud, unidades in sorted(units_tool.unidades_conocidas().items()):
        lineas.append(f"  {magnitud}:")
        lineas.append(color.suave("    " + ", ".join(unidades)))
    lineas.append("")
    lineas.append(color.suave("  Ejemplos: '72 km/h a m/s', '100 °C a °F', '2 GB a MB'"))
    return "\n".join(lineas)


AYUDA_SESION = """
Comandos disponibles:
  /materia <nombre>   fija la materia (p. ej. /materia fisica); /materia auto la libera
  /limpiar            olvida la conversación anterior
  /detalle            muestra u oculta la traza técnica
  /materias           lista las materias
  /unidades           lista las unidades convertibles
  /ayuda              muestra esta ayuda
  /salir              termina la sesión
""".strip()


# ------------------------------------------------------------------ sesión

def sesion_interactiva(agente: AgenteMoonLight, color: Color, detalle: bool) -> int:
    print(banner(agente.config, color))
    print()
    materia_fija: str | None = None

    while True:
        try:
            etiqueta = f"[{materia_fija}] " if materia_fija else ""
            entrada = input(f"{etiqueta}tú › ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nHasta luego.")
            return 0

        if not entrada:
            continue

        if entrada.startswith("/"):
            partes = entrada.split(maxsplit=1)
            comando = partes[0].lower()
            argumento = partes[1].strip() if len(partes) > 1 else ""

            if comando in ("/salir", "/exit", "/quit"):
                print("Hasta luego.")
                return 0
            if comando == "/limpiar":
                agente.reiniciar()
                print(color.suave("Memoria vaciada."))
                continue
            if comando == "/detalle":
                detalle = not detalle
                print(color.suave(f"Traza técnica: {'activada' if detalle else 'desactivada'}."))
                continue
            if comando == "/materia":
                if not argumento or argumento.lower() in ("auto", "ninguna", "-"):
                    materia_fija = None
                    print(color.suave("Materia automática."))
                else:
                    encontrada = resolver_materia(argumento)
                    if encontrada is None:
                        print(color.aviso(
                            f"No conozco la materia '{argumento}'. Usa /materias para verlas."
                        ))
                    else:
                        materia_fija = encontrada.nombre
                        print(color.suave(f"Materia fijada: {encontrada.etiqueta}."))
                continue
            if comando == "/materias":
                print(listar_materias(color))
                continue
            if comando == "/unidades":
                print(listar_unidades(color))
                continue
            if comando == "/ayuda":
                print(AYUDA_SESION)
                continue
            print(color.aviso(f"Comando desconocido: {comando}. Usa /ayuda."))
            continue

        try:
            respuesta = agente.responder(entrada, materia_forzada=materia_fija)
        except KeyboardInterrupt:
            print(color.suave("\n(consulta interrumpida)"))
            continue

        print()
        print(color.titulo(f"{NOMBRE} ›"), respuesta.materia)
        print(respuesta.formato(detalle=detalle))
        print()


# ------------------------------------------------------------------ CLI

def construir_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="moonlight",
        description=f"{NOMBRE}: tutor de estudio multi-materia con cálculo exacto.",
        epilog=(
            "Ejemplos:\n"
            "  moonlight \"deriva x^3*sin(x)\"\n"
            "  moonlight \"convierte 72 km/h a m/s\"\n"
            "  moonlight --materia historia \"causas de la Revolución Francesa\"\n"
            "  moonlight                 (sesión interactiva)\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("pregunta", nargs="*", help="pregunta a resolver")
    parser.add_argument("-m", "--materia", help="fuerza una materia concreta")
    parser.add_argument("-d", "--detalle", action="store_true", help="muestra la traza técnica")
    parser.add_argument("--sin-herramientas", action="store_true",
                        help="desactiva el cálculo y las conversiones")
    parser.add_argument("--modelo", help="nombre del modelo a usar")
    parser.add_argument("--base-url", help="URL base compatible con OpenAI (también servidores locales)")
    parser.add_argument("--nivel", help="nivel del estudiante (p. ej. 'primaria')")
    parser.add_argument("--materias", action="store_true", help="lista las materias y termina")
    parser.add_argument("--unidades", action="store_true", help="lista las unidades y termina")
    parser.add_argument("--config", action="store_true", help="muestra la configuración activa")
    parser.add_argument("-v", "--verbose", action="count", default=0,
                        help="más detalle de registro (-vv para depuración)")
    parser.add_argument("--version", action="version", version=f"{NOMBRE} {VERSION}")
    return parser


def _configurar_registro(verbose: int) -> None:
    nivel = logging.WARNING
    if verbose == 1:
        nivel = logging.INFO
    elif verbose >= 2:
        nivel = logging.DEBUG
    logging.basicConfig(
        level=nivel,
        format="%(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )


def main(argv: list[str] | None = None) -> int:
    parser = construir_parser()
    args = parser.parse_args(argv)
    _configurar_registro(args.verbose)
    color = Color(_usar_color())

    if args.materias:
        print(listar_materias(color))
        return 0
    if args.unidades:
        print(listar_unidades(color))
        return 0

    cambios: dict[str, object] = {}
    if args.modelo:
        cambios["modelo"] = args.modelo
    if args.base_url:
        cambios["base_url"] = args.base_url
    if args.nivel:
        cambios["nivel"] = args.nivel
    if args.sin_herramientas:
        cambios["herramientas_activas"] = False

    try:
        config = Config().con(**cambios) if cambios else Config()
    except ErrorConfig as exc:
        print(color.error(f"Configuración inválida: {exc}"), file=sys.stderr)
        return 1

    if args.config:
        print(color.titulo("Configuración activa"))
        print(f"  {config.resumen()}")
        print(f"  variable de credencial : {config.api_key_env}")
        print(f"  credencial detectada   : {'sí' if not config.modo_local else 'no'}")
        print(f"  temperatura            : {config.temperatura}")
        print(f"  máximo de tokens       : {config.max_tokens}")
        print(f"  memoria (turnos)       : {config.memoria_max_turnos}")
        print(f"  herramientas           : {'activas' if config.herramientas_activas else 'desactivadas'}")
        return 0

    agente = AgenteMoonLight(config)

    if not args.pregunta:
        return sesion_interactiva(agente, color, args.detalle)

    pregunta = " ".join(args.pregunta)
    try:
        respuesta = agente.responder(pregunta, materia_forzada=args.materia)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:  # noqa: BLE001 - última red de seguridad de la CLI
        logging.getLogger("moonlight.cli").exception("Fallo inesperado")
        print(color.error(f"Error inesperado: {exc}"), file=sys.stderr)
        return 2

    print(respuesta.formato(detalle=args.detalle))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
