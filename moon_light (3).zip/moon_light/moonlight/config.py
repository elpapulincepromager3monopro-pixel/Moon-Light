"""Configuración de Moon Light.

Las credenciales SIEMPRE se leen del entorno, nunca del código fuente.

Mejora respecto a versiones anteriores: los valores de entorno se resuelven en el
momento de crear la configuración (`default_factory`), no al importar el módulo.
Así, si cambias una variable de entorno en caliente (notebooks, pruebas, un
servidor que recarga), la siguiente instancia la respeta.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from urllib.parse import urlparse

# Nombre del producto, en un solo sitio para no repetirlo por todo el código.
NOMBRE = "Moon Light"
VERSION = "2.0.0"

_ESQUEMAS_PERMITIDOS = ("http", "https")


class ErrorConfig(ValueError):
    """Configuración inválida."""


def _env(nombre: str, defecto: str) -> str:
    valor = os.getenv(nombre)
    return valor.strip() if valor and valor.strip() else defecto


def _env_float(nombre: str, defecto: float) -> float:
    bruto = os.getenv(nombre)
    if not bruto:
        return defecto
    try:
        return float(bruto)
    except ValueError:
        return defecto


def _env_int(nombre: str, defecto: int) -> int:
    bruto = os.getenv(nombre)
    if not bruto:
        return defecto
    try:
        return int(bruto)
    except ValueError:
        return defecto


@dataclass(frozen=True)
class Config:
    """Parámetros de ejecución de Moon Light.

    La clave del modelo se toma de la variable indicada en `api_key_env`
    (por defecto ``MOONLIGHT_API_KEY``, con ``OPENAI_API_KEY`` como respaldo).
    Si no hay clave, Moon Light funciona en **modo local**: sigue resolviendo
    matemáticas, física y conversiones, y entrega el método de estudio.
    """

    modelo: str = field(default_factory=lambda: _env("MOONLIGHT_MODELO", "gpt-4o-mini"))
    base_url: str = field(
        default_factory=lambda: _env("MOONLIGHT_BASE_URL", "https://api.openai.com/v1")
    )
    api_key_env: str = field(default_factory=lambda: _env("MOONLIGHT_API_KEY_ENV", "MOONLIGHT_API_KEY"))
    # Si `api_key_env` no existe, se prueban estas por orden (compatibilidad).
    api_key_env_respaldo: tuple[str, ...] = ("OPENAI_API_KEY",)

    temperatura: float = field(default_factory=lambda: _env_float("MOONLIGHT_TEMPERATURA", 0.3))
    max_tokens: int = field(default_factory=lambda: _env_int("MOONLIGHT_MAX_TOKENS", 1200))
    timeout_s: float = field(default_factory=lambda: _env_float("MOONLIGHT_TIMEOUT", 60.0))
    max_reintentos: int = field(default_factory=lambda: _env_int("MOONLIGHT_REINTENTOS", 2))

    # Turnos completos (pregunta + respuesta) que se recuerdan.
    memoria_max_turnos: int = field(default_factory=lambda: _env_int("MOONLIGHT_MEMORIA", 6))

    idioma: str = field(default_factory=lambda: _env("MOONLIGHT_IDIOMA", "es"))
    nivel: str = field(default_factory=lambda: _env("MOONLIGHT_NIVEL", "secundaria/universidad"))

    herramientas_activas: bool = True
    # Segundos máximos que puede tardar un cálculo simbólico antes de abortarse.
    limite_calculo_s: float = field(default_factory=lambda: _env_float("MOONLIGHT_LIMITE_CALCULO", 8.0))
    # Confianza mínima del enrutador para asignar una materia concreta.
    umbral_materia: float = 0.18

    def __post_init__(self) -> None:
        if not 0.0 <= self.temperatura <= 2.0:
            raise ErrorConfig("La temperatura debe estar entre 0 y 2.")
        if self.max_tokens < 64:
            raise ErrorConfig("max_tokens demasiado bajo (mínimo 64).")
        if self.timeout_s <= 0:
            raise ErrorConfig("El tiempo de espera debe ser positivo.")
        if self.memoria_max_turnos < 0:
            raise ErrorConfig("La memoria no puede ser negativa.")
        if self.limite_calculo_s <= 0:
            raise ErrorConfig("El límite de cálculo debe ser positivo.")
        esquema = urlparse(self.base_url).scheme.lower()
        if esquema not in _ESQUEMAS_PERMITIDOS:
            raise ErrorConfig(
                f"base_url debe empezar por http:// o https:// (recibido: '{self.base_url}')."
            )

    # ------------------------------------------------------------------ claves

    @property
    def api_key(self) -> str | None:
        """Clave del modelo, o None si no hay ninguna definida."""
        for nombre in (self.api_key_env, *self.api_key_env_respaldo):
            valor = os.getenv(nombre)
            if valor and valor.strip():
                return valor.strip()
        return None

    @property
    def modo_local(self) -> bool:
        """True cuando no hay credencial y hay que responder sin modelo."""
        return self.api_key is None

    @property
    def endpoint_chat(self) -> str:
        return f"{self.base_url.rstrip('/')}/chat/completions"

    @property
    def es_servidor_local(self) -> bool:
        """True si apunta a un modelo en la propia máquina (Ollama, LM Studio...)."""
        host = (urlparse(self.base_url).hostname or "").lower()
        return host in {"localhost", "127.0.0.1", "::1", "0.0.0.0"}

    def con(self, **cambios: object) -> "Config":
        """Copia la configuración cambiando solo lo indicado."""
        return replace(self, **cambios)  # type: ignore[arg-type]

    def resumen(self) -> str:
        """Descripción legible; nunca incluye la clave."""
        estado = "modo local (sin modelo)" if self.modo_local else f"modelo {self.modelo}"
        destino = "servidor local" if self.es_servidor_local else self.base_url
        return f"{NOMBRE} {VERSION} · {estado} · {destino} · nivel {self.nivel}"
