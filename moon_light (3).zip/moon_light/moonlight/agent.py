"""Agente de Moon Light: enruta, usa herramientas y compone la respuesta.

Flujo por pregunta:
  1. Enrutar a la materia adecuada (o al tutor general).
  2. Ejecutar herramientas deterministas cuando aporten certeza
     (cálculo simbólico, conversión de unidades).
  3. Pedir la explicación al modelo pasándole el resultado ya calculado.
  4. Si no hay modelo disponible, entregar una respuesta local útil:
     el resultado exacto de la herramienta más el método de estudio.

Mejoras de esta versión:
  * Ya no hay `except (ErrorX, Exception)` ni `except Exception: pass`. Cada
    fallo de herramienta se captura por su tipo, se registra y se convierte en
    un aviso legible para el estudiante.
  * La memoria guarda turnos completos y se recorta por turnos, no por mensajes
    sueltos, para no dejar una pregunta sin su respuesta.
  * `Respuesta` incluye trazas (materia, herramientas, avisos, tokens).
  * Registro con `logging`; el llamador decide si lo muestra.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

from .config import NOMBRE, Config
from .llm import (
    ClienteLLM,
    ErrorAutenticacion,
    ErrorLLM,
    Mensaje,
)
from .router import Decision, enrutar
from .subjects import BASE_PEDAGOGICA, MATERIA_GENERAL, Materia, resolver_materia
from .tools import math_tool, units_tool

log = logging.getLogger("moonlight.agent")


@dataclass
class Turno:
    """Una pregunta con su respuesta, la unidad mínima de memoria."""

    pregunta: str
    respuesta: str


@dataclass
class Respuesta:
    """Lo que Moon Light devuelve al estudiante, con su rastro de ejecución."""

    texto: str
    materia: str
    confianza: float
    origen: str                              # "modelo" | "local"
    herramientas: tuple[str, ...] = ()
    avisos: tuple[str, ...] = ()
    explicacion_ruta: str = ""
    tokens: int = 0
    segundos: float = 0.0

    def formato(self, detalle: bool = False) -> str:
        partes = [self.texto]
        if self.avisos:
            partes.append("\n" + "\n".join(f"⚠ {a}" for a in self.avisos))
        if detalle:
            traza = [
                f"materia: {self.materia} ({self.confianza:.0%})",
                f"origen: {self.origen}",
            ]
            if self.herramientas:
                traza.append("herramientas: " + ", ".join(self.herramientas))
            if self.tokens:
                traza.append(f"tokens: {self.tokens}")
            traza.append(f"tiempo: {self.segundos:.2f} s")
            if self.explicacion_ruta:
                traza.append(f"ruta: {self.explicacion_ruta}")
            partes.append("\n— " + " · ".join(traza))
        return "\n".join(partes)


@dataclass
class ResultadoHerramientas:
    bloques: list[str] = field(default_factory=list)
    usadas: list[str] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)

    @property
    def hay_datos(self) -> bool:
        return bool(self.bloques)

    def texto(self) -> str:
        return "\n\n".join(self.bloques)


class AgenteMoonLight:
    """Tutor multi-materia con herramientas deterministas."""

    def __init__(self, config: Config | None = None, cliente: ClienteLLM | None = None) -> None:
        self.config = config or Config()
        self.cliente = cliente or ClienteLLM(self.config)
        self.memoria: list[Turno] = []

    # ------------------------------------------------------------- público

    def responder(self, pregunta: str, materia_forzada: str | None = None) -> Respuesta:
        """Resuelve una pregunta completa."""
        inicio = time.perf_counter()
        pregunta = (pregunta or "").strip()
        if not pregunta:
            return Respuesta(
                texto="Escribe tu pregunta y la trabajamos juntos.",
                materia=MATERIA_GENERAL.nombre,
                confianza=0.0,
                origen="local",
            )

        decision = self._decidir(pregunta, materia_forzada)
        materia = decision.materia

        herramientas = ResultadoHerramientas()
        if self.config.herramientas_activas:
            herramientas = self._usar_herramientas(pregunta, materia)

        if self.cliente.disponible:
            try:
                respuesta = self._responder_con_modelo(pregunta, decision, herramientas)
            except ErrorAutenticacion as exc:
                log.info("Sin credencial válida, paso a modo local: %s", exc)
                herramientas.avisos.append(
                    "No hay acceso al modelo, respondo en modo local con el método de estudio."
                )
                respuesta = self._responder_local(pregunta, decision, herramientas)
            except ErrorLLM as exc:
                log.warning("Fallo del modelo (%s), paso a modo local.", type(exc).__name__)
                herramientas.avisos.append(f"El modelo no respondió: {exc}")
                respuesta = self._responder_local(pregunta, decision, herramientas)
        else:
            respuesta = self._responder_local(pregunta, decision, herramientas)

        respuesta.segundos = time.perf_counter() - inicio
        self._recordar(pregunta, respuesta.texto)
        return respuesta

    def reiniciar(self) -> None:
        """Vacía la memoria de la conversación."""
        self.memoria.clear()

    # ------------------------------------------------------------- enrutado

    def _decidir(self, pregunta: str, materia_forzada: str | None) -> Decision:
        if materia_forzada:
            materia = resolver_materia(materia_forzada)
            if materia is not None:
                return Decision(materia, 1.0, motivos=("materia indicada por el usuario",))
            log.info("Materia '%s' desconocida; uso el enrutador automático.", materia_forzada)
        return enrutar(pregunta, umbral=self.config.umbral_materia)

    # --------------------------------------------------------- herramientas

    def _usar_herramientas(self, pregunta: str, materia: Materia) -> ResultadoHerramientas:
        """Ejecuta las herramientas pertinentes capturando cada fallo por su tipo."""
        resultado = ResultadoHerramientas()

        # --- conversión de unidades ---------------------------------------
        if units_tool.parece_conversion(pregunta):
            try:
                conversion = units_tool.interpretar(pregunta)
                resultado.bloques.append(
                    "Conversión de unidades (calculada, exacta):\n" + conversion.formato()
                )
                resultado.usadas.append("unidades")
            except units_tool.MagnitudIncompatible as exc:
                resultado.avisos.append(str(exc))
            except units_tool.UnidadDesconocida as exc:
                resultado.avisos.append(
                    f"{exc} Puedo listar las unidades disponibles si lo necesitas."
                )
            except units_tool.ErrorSintaxisUnidades as exc:
                log.debug("No se pudo leer la conversión: %s", exc)
            except units_tool.ErrorUnidades as exc:
                resultado.avisos.append(str(exc))

        # --- cálculo simbólico --------------------------------------------
        if materia.usa_calculo and math_tool.detectar_operacion(pregunta):
            try:
                calculo = math_tool.calcular(pregunta, limite_s=self.config.limite_calculo_s)
                resultado.bloques.append(
                    "Cálculo simbólico (verificado con SymPy):\n" + calculo.formato()
                )
                # Etiqueta sin tilde: es un identificador de traza, no texto visible.
                resultado.usadas.append(f"matematicas:{calculo.operacion}")
            except math_tool.ErrorDependencia as exc:
                resultado.avisos.append(str(exc))
            except math_tool.ErrorTiempo as exc:
                resultado.avisos.append(
                    f"{exc} Prueba con una expresión más simple o divide el problema."
                )
            except math_tool.ErrorSintaxis as exc:
                # Muy frecuente en preguntas conceptuales: no es un fallo real.
                log.debug("Expresión no interpretable: %s", exc)
            except math_tool.ErrorMatematico as exc:
                resultado.avisos.append(str(exc))

        return resultado

    # --------------------------------------------------------- con modelo

    def _responder_con_modelo(
        self,
        pregunta: str,
        decision: Decision,
        herramientas: ResultadoHerramientas,
    ) -> Respuesta:
        mensajes = [Mensaje("system", self._instruccion_sistema(decision))]

        for turno in self.memoria[-self.config.memoria_max_turnos :]:
            mensajes.append(Mensaje("user", turno.pregunta))
            mensajes.append(Mensaje("assistant", turno.respuesta))

        contenido = pregunta
        if herramientas.hay_datos:
            contenido += (
                "\n\n[Datos ya calculados por herramientas fiables. "
                "Úsalos tal cual, no los recalcules de memoria:]\n"
                + herramientas.texto()
            )
        mensajes.append(Mensaje("user", contenido))

        respuesta_llm = self.cliente.completar(mensajes)
        return Respuesta(
            texto=respuesta_llm.texto,
            materia=decision.materia.nombre,
            confianza=decision.confianza,
            origen="modelo",
            herramientas=tuple(herramientas.usadas),
            avisos=tuple(herramientas.avisos),
            explicacion_ruta=decision.explicar(),
            tokens=respuesta_llm.tokens_total,
        )

    def _instruccion_sistema(self, decision: Decision) -> str:
        materia = decision.materia
        partes = [
            f"Eres {NOMBRE}, un tutor que enseña con rigor y claridad.",
            materia.instrucciones,
            BASE_PEDAGOGICA,
            f"Nivel del estudiante: {self.config.nivel}.",
            f"Responde en {'español' if self.config.idioma == 'es' else self.config.idioma}.",
            "Organiza la respuesta siguiendo este esquema: " + " > ".join(materia.plan) + ".",
            "Usa Markdown ligero (títulos cortos y listas) y no te excedas de lo necesario.",
        ]
        if decision.es_ambigua and decision.alternativas:
            otras = ", ".join(n for n, _ in decision.alternativas[:2])
            partes.append(
                f"La pregunta también toca {otras}: intégrelo si aporta, sin desviarte del tema."
            )
        partes.append(
            "Si algo no lo sabes o no puedes verificarlo, dilo abiertamente. "
            "Nunca inventes datos, citas ni cifras."
        )
        return "\n\n".join(partes)

    # ------------------------------------------------------------ sin modelo

    def _responder_local(
        self,
        pregunta: str,
        decision: Decision,
        herramientas: ResultadoHerramientas,
    ) -> Respuesta:
        """Respuesta útil sin modelo: resultado exacto + método de trabajo."""
        materia = decision.materia
        lineas = [f"### {materia.etiqueta}", ""]

        if herramientas.hay_datos:
            lineas.append(herramientas.texto())
            lineas.append("")
            lineas.append(
                "Este resultado es exacto: lo calculó el motor simbólico, no un modelo de lenguaje."
            )
            lineas.append("")

        lineas.append("**Cómo abordar esta pregunta paso a paso:**")
        lineas.extend(f"{i}. {paso}" for i, paso in enumerate(materia.plan, start=1))
        lineas.append("")

        if materia.ejemplos:
            lineas.append(f"Ejemplo del tipo de pregunta: {materia.ejemplos[0]}")
            lineas.append("")

        lineas.append(
            "Estoy en **modo local**: resuelvo cálculos y conversiones con exactitud, "
            f"pero para la explicación redactada necesito una credencial en "
            f"`{self.config.api_key_env}` (o una URL base que apunte a un modelo local)."
        )

        return Respuesta(
            texto="\n".join(lineas).strip(),
            materia=materia.nombre,
            confianza=decision.confianza,
            origen="local",
            herramientas=tuple(herramientas.usadas),
            avisos=tuple(herramientas.avisos),
            explicacion_ruta=decision.explicar(),
        )

    # -------------------------------------------------------------- memoria

    def _recordar(self, pregunta: str, respuesta: str) -> None:
        if self.config.memoria_max_turnos <= 0:
            return
        self.memoria.append(Turno(pregunta, respuesta))
        exceso = len(self.memoria) - self.config.memoria_max_turnos
        if exceso > 0:
            del self.memoria[:exceso]
