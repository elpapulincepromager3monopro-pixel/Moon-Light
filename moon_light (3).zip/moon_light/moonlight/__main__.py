"""Punto de entrada de `python -m moonlight`: delega en la consola."""

from .cli import main

if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
