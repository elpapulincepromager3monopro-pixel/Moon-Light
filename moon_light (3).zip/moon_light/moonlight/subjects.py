"""Catálogo de materias de Moon Light y su forma de enseñar.

Cada materia aporta cuatro cosas:
  * `palabras_clave`  señales léxicas para el enrutador.
  * `antipalabras`    señales que RESTAN (evitan robos de materia ajenos).
  * `instrucciones`   cómo debe razonar y responder el especialista.
  * `plan`            esqueleto de respuesta, usado también en modo local.

Mejoras de esta versión:
  * Coincidencia tolerante a plurales y género ("novelas", "metafóricos").
  * Antipalabras para desambiguar solapes clásicos
    ("función del narrador" es literatura, no matemáticas).
  * Puntuación normalizada: una materia con muchas palabras clave ya no gana
    solo por tener el vocabulario más largo.
  * Materias nuevas: Arte y música, Geografía.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from functools import lru_cache


@lru_cache(maxsize=4096)
def normalizar(texto: str) -> str:
    """Minúsculas sin acentos, para comparar de forma estable."""
    descompuesto = unicodedata.normalize("NFD", texto.lower())
    return "".join(c for c in descompuesto if unicodedata.category(c) != "Mn")


# Sufijos que se toleran al final de una palabra clave: plurales y género.
# "novela" casa con "novelas"; "metafora" con "metaforas"; "historico" con "historicos".
_SUFIJOS = r"(?:s|es|as|os|a|ales|iones)?"


@lru_cache(maxsize=8192)
def _patron_clave(clave_normalizada: str) -> re.Pattern[str]:
    """Compila (y memoiza) el patrón de una palabra clave.

    Se exige límite de palabra al inicio y se permite una terminación flexible,
    de modo que la clave no casa dentro de otra palabra sin relación.
    """
    partes = [re.escape(p) for p in clave_normalizada.split()]
    cuerpo = r"\s+".join(partes)
    return re.compile(rf"(?<!\w){cuerpo}{_SUFIJOS}(?!\w)")


@dataclass(frozen=True)
class Materia:
    nombre: str
    etiqueta: str
    palabras_clave: tuple[str, ...]
    instrucciones: str
    plan: tuple[str, ...]
    antipalabras: tuple[str, ...] = field(default_factory=tuple)
    usa_calculo: bool = False
    peso: float = 1.0
    ejemplos: tuple[str, ...] = field(default_factory=tuple)

    def coincidencias(self, pregunta: str) -> tuple[str, ...]:
        """Palabras clave que aparecen en la pregunta (útil para explicar el porqué)."""
        texto = normalizar(pregunta)
        return tuple(
            clave
            for clave in self.palabras_clave
            if _patron_clave(normalizar(clave)).search(texto)
        )

    def puntuar(self, pregunta: str) -> float:
        """Puntaje de afinidad con la pregunta.

        Las claves de varias palabras valen más porque son más específicas.
        Las antipalabras restan. El total se normaliza para que el tamaño del
        vocabulario de la materia no decida por sí solo.
        """
        texto = normalizar(pregunta)
        total = 0.0
        for clave in self.palabras_clave:
            if _patron_clave(normalizar(clave)).search(texto):
                total += 1.6 if " " in clave else 1.0
        for anti in self.antipalabras:
            if _patron_clave(normalizar(anti)).search(texto):
                total -= 1.4
        if total <= 0:
            return 0.0
        # Rendimiento decreciente: 5 coincidencias no valen 5 veces más que una.
        return (total ** 0.75) * self.peso


BASE_PEDAGOGICA = (
    "Enseña, no solo respondas: parte de lo que el estudiante ya sabe, usa un "
    "ejemplo concreto y cierra con una pregunta de comprobación. Si un dato es "
    "incierto o discutido, dilo en lugar de inventarlo."
)


MATERIAS: tuple[Materia, ...] = (
    Materia(
        nombre="literatura",
        etiqueta="Literatura",
        palabras_clave=(
            "literatura", "literario", "novela", "poema", "poesia", "verso", "soneto",
            "metafora", "narrador", "personaje", "trama", "genero literario",
            "cuento", "teatro", "tragedia", "comedia", "realismo magico",
            "analisis literario", "rima", "simbolo", "quijote", "borges",
            "garcia marquez", "rulfo", "neruda", "protagonista", "antagonista",
            "voz narrativa", "figura retorica", "estrofa", "vanguardia",
        ),
        antipalabras=("deriva", "integral", "ecuacion"),
        instrucciones=(
            "Eres especialista en literatura. Analiza la obra por niveles: forma "
            "(género, estructura, voz narrativa, métrica), contenido (temas, "
            "símbolos, conflicto) y contexto (movimiento, época, recepción). "
            "Cita el texto cuando sostenga tu lectura y distingue siempre entre "
            "lo que el texto dice y lo que es interpretación tuya. Si no estás "
            "seguro de que una cita sea literal, parafrasea y avísalo."
        ),
        plan=(
            "Obra, autor y contexto",
            "Estructura y voz narrativa",
            "Temas y símbolos con evidencia textual",
            "Lectura crítica e interpretaciones alternativas",
            "Para practicar",
        ),
        ejemplos=("¿Qué función cumple el narrador en Pedro Páramo?",),
    ),
    Materia(
        nombre="escritura",
        etiqueta="Escritura y redacción",
        palabras_clave=(
            "escritura", "redaccion", "redactar", "ensayo", "corrige", "corregir",
            "ortografia", "gramatica", "estilo", "parrafo", "tesis", "resumen",
            "carta", "informe", "citas apa", "coherencia", "cohesion",
            "puntuacion", "mejora este texto", "revisa este texto", "tilde",
            "conector", "introduccion y conclusion", "reescribe",
        ),
        instrucciones=(
            "Eres editor y profesor de escritura. Devuelve el texto mejorado y, "
            "aparte, una lista breve de los cambios con su motivo (claridad, "
            "concordancia, registro, puntuación). Respeta la voz del autor: "
            "corrige, no reescribas su personalidad. Señala tesis débiles y "
            "párrafos sin idea principal. No inventes contenido que el autor no "
            "escribió; si falta información, márcala como hueco por rellenar."
        ),
        plan=(
            "Diagnóstico del texto",
            "Versión corregida",
            "Cambios y por qué",
            "Estructura sugerida",
            "Un ejercicio de reescritura",
        ),
    ),
    Materia(
        nombre="historia",
        etiqueta="Historia",
        palabras_clave=(
            "historia", "historico", "guerra", "revolucion", "imperio", "tratado",
            "siglo", "independencia", "colonia", "dinastia", "edad media",
            "prehistoria", "causas de", "consecuencias de", "cronologia",
            "virreinato", "conquista", "guerra fria", "revolucion industrial",
            "antiguo regimen", "feudalismo", "renacimiento", "ilustracion",
            "dictadura", "monarquia",
        ),
        instrucciones=(
            "Eres historiador. Ubica siempre tiempo y lugar, separa causas "
            "estructurales de coyunturales y distingue hechos documentados de "
            "interpretaciones historiográficas. Evita el anacronismo y menciona "
            "cuando existan versiones en disputa. Si no recuerdas una fecha con "
            "certeza, indica el rango y advíertelo explícitamente: es preferible "
            "decir 'a mediados del siglo XIX' que arriesgar un año falso."
        ),
        plan=(
            "Contexto: cuándo y dónde",
            "Causas (estructurales y detonantes)",
            "Desarrollo cronológico",
            "Consecuencias y legado",
            "Debate historiográfico",
        ),
    ),
    Materia(
        nombre="matematicas",
        etiqueta="Matemáticas",
        palabras_clave=(
            "matematica", "ecuacion", "derivada", "deriva", "integral", "integra",
            "limite", "algebra", "geometria", "trigonometria", "probabilidad",
            "estadistica", "matriz", "vector", "factoriza", "resuelve", "calcula",
            "demuestra", "simplifica", "polinomio", "logaritmo",
            "sistema de ecuaciones", "grafica", "despeja", "raiz cuadrada",
            "numero primo", "fraccion", "porcentaje", "combinatoria", "teorema",
        ),
        antipalabras=("narrador", "poema", "personaje"),
        instrucciones=(
            "Eres profesor de matemáticas. Muestra el razonamiento paso a paso, "
            "nombrando la propiedad o teorema usado en cada paso. Verifica el "
            "resultado sustituyendo o con un caso límite. Cuando recibas la salida "
            "de la herramienta de cálculo, trata ese valor como correcto y dedica "
            "tu respuesta a explicar el camino, no a recalcular de memoria."
        ),
        plan=(
            "Qué se pide y qué datos hay",
            "Estrategia y teoremas aplicables",
            "Desarrollo paso a paso",
            "Resultado y verificación",
            "Error típico a evitar",
        ),
        usa_calculo=True,
        peso=1.1,
    ),
    Materia(
        nombre="fisica",
        etiqueta="Física",
        palabras_clave=(
            "fisica", "fuerza", "velocidad", "aceleracion", "energia", "masa",
            "newton", "joule", "momento", "cinematica", "dinamica",
            "termodinamica", "electromagnetismo", "circuito", "onda", "optica",
            "relatividad", "cuantica", "gravedad", "friccion", "presion",
            "caida libre", "plano inclinado", "trabajo mecanico", "potencia",
            "voltaje", "corriente electrica", "resistencia", "empuje",
        ),
        instrucciones=(
            "Eres profesor de física. Empieza por el modelo y las suposiciones "
            "(sistema, marco de referencia, qué se desprecia), plantea la ley que "
            "gobierna el problema y solo después sustituye números. Trabaja en "
            "unidades del SI y comprueba la coherencia dimensional del resultado. "
            "Termina siempre diciendo si el orden de magnitud es razonable."
        ),
        plan=(
            "Modelo y suposiciones",
            "Datos con unidades",
            "Leyes y ecuaciones",
            "Cálculo y análisis dimensional",
            "Interpretación física del resultado",
        ),
        usa_calculo=True,
        peso=1.05,
    ),
    Materia(
        nombre="ciencias",
        etiqueta="Ciencias naturales",
        palabras_clave=(
            "ciencias", "biologia", "quimica", "celula", "adn", "gen", "evolucion",
            "ecosistema", "fotosintesis", "mitosis", "meiosis", "atomo",
            "molecula", "reaccion quimica", "tabla periodica", "enlace", "ph",
            "mol", "geologia", "astronomia", "planeta", "virus", "bacteria",
            "metodo cientifico", "proteina", "enzima", "sistema nervioso",
            "respiracion celular", "tejido",
        ),
        instrucciones=(
            "Eres divulgador científico riguroso (biología, química, ciencias de "
            "la Tierra y astronomía). Explica el mecanismo, no solo el nombre del "
            "fenómeno. Diferencia consenso científico de hipótesis abierta y "
            "corrige de forma explícita las ideas erróneas más comunes. En "
            "química, balancea las ecuaciones antes de calcular. No des consejo "
            "médico: explica la biología y remite a un profesional sanitario."
        ),
        plan=(
            "Idea central en una frase",
            "Mecanismo paso a paso",
            "Ejemplo o experimento observable",
            "Concepción errónea frecuente",
            "Para profundizar",
        ),
    ),
    Materia(
        nombre="programacion",
        etiqueta="Programación e informática",
        palabras_clave=(
            "programacion", "codigo", "python", "javascript", "java", "algoritmo",
            "funcion recursiva", "recursividad", "bug", "error de codigo",
            "complejidad", "sql", "estructura de datos", "api", "compilar",
            "depurar", "bucle", "variable", "git", "framework", "base de datos",
            "pruebas unitarias",
        ),
        instrucciones=(
            "Eres mentor de programación. Da código ejecutable y comentado, "
            "explica la complejidad y los casos borde, y señala riesgos de "
            "seguridad cuando existan (inyección, credenciales en el código, "
            "endpoints sin autenticación). Prefiere la solución legible antes que "
            "la ingeniosa, y di cómo probar lo que propones."
        ),
        plan=(
            "Problema y restricciones",
            "Idea de la solución",
            "Código comentado",
            "Complejidad y casos borde",
            "Cómo probarlo",
        ),
    ),
    Materia(
        nombre="filosofia",
        etiqueta="Filosofía y ciencias sociales",
        palabras_clave=(
            "filosofia", "etica", "moral", "epistemologia", "ontologia", "logica",
            "platon", "aristoteles", "kant", "nietzsche", "descartes", "argumento",
            "falacia", "economia", "sociologia", "psicologia", "politica",
            "derecho", "justicia", "libre albedrio", "existencialismo",
            "contrato social",
        ),
        instrucciones=(
            "Eres especialista en filosofía y ciencias sociales. Reconstruye el "
            "argumento (premisas y conclusión), presenta al menos dos posturas "
            "rivales en su mejor versión y señala falacias si aparecen. En "
            "cuestiones normativas no impongas una postura como verdad única: "
            "muestra el desacuerdo razonable y deja la decisión al estudiante."
        ),
        plan=(
            "Aclaración de los conceptos",
            "Argumento reconstruido",
            "Posturas en tensión",
            "Objeciones y réplicas",
            "Pregunta para pensar",
        ),
    ),
    Materia(
        nombre="idiomas",
        etiqueta="Idiomas",
        palabras_clave=(
            "traduce", "traduccion", "ingles", "frances", "aleman", "latin",
            "italiano", "portugues", "conjuga", "verbo irregular", "pronunciacion",
            "vocabulario", "como se dice", "phrasal verb", "subjuntivo",
            "falso amigo",
        ),
        instrucciones=(
            "Eres profesor de idiomas. Da la forma correcta, explica la regla "
            "gramatical que la sostiene y ofrece un ejemplo de uso real. Marca el "
            "registro (formal/informal), los falsos amigos y las diferencias "
            "regionales cuando importen."
        ),
        plan=(
            "Respuesta directa",
            "Regla gramatical",
            "Ejemplos de uso",
            "Errores frecuentes",
            "Mini práctica",
        ),
    ),
    Materia(
        nombre="arte",
        etiqueta="Arte y música",
        palabras_clave=(
            "arte", "pintura", "pintor", "escultura", "arquitectura", "museo",
            "barroco", "impresionismo", "cubismo", "surrealismo", "perspectiva",
            "musica", "acorde", "escala musical", "armonia", "compas", "partitura",
            "melodia", "ritmo", "sinfonia", "opera", "cine", "fotografia",
            "picasso", "van gogh", "beethoven",
        ),
        instrucciones=(
            "Eres especialista en historia del arte y música. Describe primero lo "
            "que se ve o se oye (materia, forma, técnica, instrumentación), luego "
            "el significado y por último el contexto de la obra y su recepción. "
            "Distingue el dato documentado del juicio estético personal."
        ),
        plan=(
            "Obra, autor y época",
            "Descripción formal (qué se ve u oye)",
            "Técnica y lenguaje artístico",
            "Significado y contexto",
            "Obras para comparar",
        ),
    ),
    Materia(
        nombre="geografia",
        etiqueta="Geografía",
        palabras_clave=(
            "geografia", "continente", "pais", "capital de", "rio", "cordillera",
            "clima", "relieve", "poblacion", "migracion", "mapa", "latitud",
            "longitud", "husos horarios", "placa tectonica", "desierto",
            "oceano", "urbanizacion", "recursos naturales",
        ),
        instrucciones=(
            "Eres profesor de geografía. Conecta siempre el rasgo físico con su "
            "efecto humano (población, economía, riesgo). Usa datos cuantitativos "
            "cuando los recuerdes con seguridad y advierte cuando una cifra sea "
            "aproximada o pueda estar desactualizada."
        ),
        plan=(
            "Localización",
            "Rasgos físicos",
            "Dimensión humana y económica",
            "Causas y procesos",
            "Dato para recordar",
        ),
    ),
)


MATERIA_GENERAL = Materia(
    nombre="general",
    etiqueta="Tutor general",
    palabras_clave=(),
    instrucciones=(
        "Eres un tutor generalista. Identifica primero de qué área es la "
        "pregunta, responde con precisión y admite explícitamente lo que no sabes "
        "en lugar de rellenar con suposiciones."
    ),
    plan=(
        "Qué se está preguntando",
        "Respuesta fundamentada",
        "Ejemplo aclaratorio",
        "Límites de la respuesta",
        "Siguiente paso de estudio",
    ),
)


MATERIAS_POR_NOMBRE: dict[str, Materia] = {m.nombre: m for m in MATERIAS}
MATERIAS_POR_NOMBRE[MATERIA_GENERAL.nombre] = MATERIA_GENERAL

# Alias frecuentes para que `--materia` acepte lo que la gente escribe de verdad.
ALIAS_MATERIAS: dict[str, str] = {
    "mate": "matematicas", "matematica": "matematicas", "math": "matematicas",
    "algebra": "matematicas", "calculo": "matematicas",
    "lengua": "escritura", "redaccion": "escritura", "gramatica": "escritura",
    "biologia": "ciencias", "quimica": "ciencias", "bio": "ciencias",
    "informatica": "programacion", "codigo": "programacion", "code": "programacion",
    "musica": "arte", "pintura": "arte",
    "ingles": "idiomas", "english": "idiomas",
    "economia": "filosofia", "psicologia": "filosofia", "etica": "filosofia",
    "fisicas": "fisica", "physics": "fisica",
}


def resolver_materia(nombre: str) -> Materia | None:
    """Busca una materia por nombre, etiqueta o alias. None si no existe."""
    if not nombre:
        return None
    clave = normalizar(nombre).strip()
    if clave in MATERIAS_POR_NOMBRE:
        return MATERIAS_POR_NOMBRE[clave]
    if clave in ALIAS_MATERIAS:
        return MATERIAS_POR_NOMBRE[ALIAS_MATERIAS[clave]]
    for materia in MATERIAS_POR_NOMBRE.values():
        if normalizar(materia.etiqueta) == clave:
            return materia
    return None
