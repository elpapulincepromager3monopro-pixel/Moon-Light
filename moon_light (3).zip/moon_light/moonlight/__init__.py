"""Moon Light · tutor de estudio multi-materia con herramientas exactas.

Uso rápido:

    from moonlight import AgenteMoonLight

    tutor = AgenteMoonLight()
    print(tutor.responder("deriva x^3 * sin(x)").texto)

Sin credencial funciona en modo local: sigue resolviendo matemáticas y
conversiones de unidades con exactitud y entrega el método de estudio.
"""

from .agent import AgenteMoonLight, Respuesta, Turno
from .config import NOMBRE, VERSION, Config, ErrorConfig
from .llm import ClienteLLM, ErrorLLM, Mensaje, RespuestaLLM
from .router import Decision, enrutar
from .subjects import MATERIA_GENERAL, MATERIAS, Materia, resolver_materia

__version__ = VERSION
__all__ = [
    "AgenteMoonLight",
    "Respuesta",
    "Turno",
    "Config",
    "ErrorConfig",
    "NOMBRE",
    "VERSION",
    "ClienteLLM",
    "ErrorLLM",
    "Mensaje",
    "RespuestaLLM",
    "Decision",
    "enrutar",
    "MATERIAS",
    "MATERIA_GENERAL",
    "Materia",
    "resolver_materia",
    "__version__",
]
