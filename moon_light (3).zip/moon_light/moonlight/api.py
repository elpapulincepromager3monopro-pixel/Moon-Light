"""Servidor HTTP de Moon Light (solo biblioteca estándar).

Expone el tutor por HTTP para integrarlo en una web, una app o un cliente que
ya hable el dialecto "chat completions" de OpenAI (por ejemplo el agente
Hermes, Open WebUI, LangChain, el SDK de OpenAI apuntado a otra URL base...).

SEGURIDAD — léelo antes de exponerlo:
  * El acceso se protege con un token en la cabecera ``Authorization: Bearer ...``
    (o ``X-Moon-Token``), leído de la variable de entorno ``MOONLIGHT_API_TOKEN``.
  * **Si esa variable no está definida, el servidor queda SIN AUTENTICACIÓN**:
    cualquiera que alcance el puerto podrá consumir tu credencial del modelo.
    En ese caso sólo se permite escuchar en la interfaz local (127.0.0.1) y se
    imprime un aviso bien visible; para escuchar en 0.0.0.0 hay que definir el
    token o pasar explícitamente ``--insegura``.
  * TLS: puedes servir HTTPS directamente con ``--cert``/``--clave``. Si no,
    ponlo detrás de un proxy inverso (nginx, Caddy, Traefik) que termine TLS.
  * Detrás de un proxy, el limitador vería una sola IP; activa
    ``MOONLIGHT_CONFIA_PROXY=1`` para usar ``X-Forwarded-For``. No lo actives
    si el puerto es alcanzable directamente: esa cabecera se puede falsificar.
  * Hay límite de tamaño de cuerpo y un limitador por IP muy simple, suficiente
    para uso personal, no para producción abierta.

Rutas propias:
  GET  /salud                 estado y capacidades del servicio
  GET  /materias              materias disponibles
  GET  /unidades              catálogo de unidades convertibles
  POST /preguntar             {"pregunta": "...", "materia": "fisica",
                               "historial": [...], "stream": false}

Rutas compatibles estilo OpenAI (para clientes como Hermes):
  GET  /v1/models
  POST /v1/chat/completions   {"model": "...", "messages": [...], "stream": true}

Con ``stream: true`` la respuesta llega como *Server-Sent Events*. El tutor
calcula la respuesta completa y la entrega por fragmentos (no es palabra por
palabra del modelo), así que el cliente puede ir pintando texto sin esperar.

CORS: desactivado salvo que definas ``MOONLIGHT_CORS`` (``*`` o una lista de
orígenes separados por comas). Incluye respuesta a ``OPTIONS`` (preflight).

Concurrencia: cada hilo usa su propio agente, así que las peticiones se
atienden en paralelo y no se contaminan entre sí. El estado de conversación
viaja en la petición (``historial`` o ``messages``), no en el servidor.
"""

from __future__ import annotations

import argparse
import hmac
import json
import logging
import os
import ssl
import threading
import time
import uuid
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Iterator

from .agent import AgenteMoonLight, Turno
from .config import NOMBRE, VERSION, Config, ErrorConfig
from .subjects import MATERIAS, resolver_materia
from .tools import units_tool

log = logging.getLogger("moonlight.api")

VAR_TOKEN = "MOONLIGHT_API_TOKEN"
VAR_CORS = "MOONLIGHT_CORS"
VAR_PROXY = "MOONLIGHT_CONFIA_PROXY"

MAX_CUERPO = 128 * 1024         # 128 KB por petición (cabe un historial largo)
MAX_PREGUNTA = 8000             # caracteres
MAX_MENSAJES = 64               # mensajes admitidos en /v1/chat/completions
VENTANA_S = 60.0
MAX_PETICIONES = 30             # por IP y ventana
TAM_FRAGMENTO = 60              # caracteres por fragmento en streaming

MODELO_EXPUESTO = "moonlight"
CABECERAS_CORS = "Authorization, Content-Type, X-Moon-Token, Accept"


class Limitador:
    """Cuenta peticiones por IP en una ventana deslizante."""

    def __init__(self, maximo: int = MAX_PETICIONES, ventana: float = VENTANA_S) -> None:
        self.maximo = maximo
        self.ventana = ventana
        self._registro: dict[str, deque[float]] = {}
        self._candado = threading.Lock()

    def permite(self, ip: str) -> bool:
        ahora = time.monotonic()
        with self._candado:
            cola = self._registro.setdefault(ip, deque())
            while cola and ahora - cola[0] > self.ventana:
                cola.popleft()
            if len(cola) >= self.maximo:
                return False
            cola.append(ahora)
            return True


def token_configurado() -> str | None:
    valor = os.getenv(VAR_TOKEN)
    return valor.strip() if valor and valor.strip() else None


def origenes_configurados() -> tuple[str, ...]:
    """Orígenes permitidos para CORS. Vacío = CORS desactivado."""
    bruto = (os.getenv(VAR_CORS) or "").strip()
    if not bruto:
        return ()
    partes = [p.strip().rstrip("/") for p in bruto.split(",")]
    return tuple(p for p in partes if p)


def confia_en_proxy() -> bool:
    return (os.getenv(VAR_PROXY) or "").strip().lower() in {"1", "si", "sí", "true", "yes"}


def fragmentar(texto: str, tamano: int = TAM_FRAGMENTO) -> list[str]:
    """Parte el texto en trozos legibles sin cortar palabras cuando se puede."""
    if tamano <= 0:
        raise ValueError("El tamaño del fragmento debe ser positivo.")
    if not texto:
        return []

    trozos: list[str] = []
    resto = texto
    while resto:
        if len(resto) <= tamano:
            trozos.append(resto)
            break
        corte = resto.rfind(" ", 0, tamano + 1)
        salto = resto.rfind("\n", 0, tamano + 1)
        corte = max(corte, salto)
        if corte <= 0:
            corte = tamano
        else:
            corte += 1                       # el separador viaja con el trozo
        trozos.append(resto[:corte])
        resto = resto[corte:]
    return trozos


def texto_de_contenido(contenido: Any) -> str:
    """Normaliza el campo ``content`` de un mensaje estilo OpenAI."""
    if isinstance(contenido, str):
        return contenido
    if isinstance(contenido, list):
        partes: list[str] = []
        for parte in contenido:
            if isinstance(parte, dict) and isinstance(parte.get("text"), str):
                partes.append(parte["text"])
        return "".join(partes)
    return ""


class ManejadorMoonLight(BaseHTTPRequestHandler):
    """Maneja las rutas del tutor. Un agente por hilo: nada de peticiones en fila."""

    server_version = f"MoonLight/{VERSION}"
    protocol_version = "HTTP/1.1"

    # Inyectados por `crear_servidor`.
    fabrica_agente: Callable[[], AgenteMoonLight]
    limitador: Limitador
    token: str | None
    origenes: tuple[str, ...] = ()
    confia_proxy: bool = False
    almacen_hilo: threading.local

    # ------------------------------------------------------------ utilidades

    def log_message(self, formato: str, *args: Any) -> None:  # noqa: A003
        log.info("%s - %s", self.address_string(), formato % args)

    @property
    def agente(self) -> AgenteMoonLight:
        """Agente propio del hilo actual (se crea la primera vez y se reutiliza)."""
        agente = getattr(self.almacen_hilo, "agente", None)
        if agente is None:
            agente = type(self).fabrica_agente()
            self.almacen_hilo.agente = agente
        return agente

    def _ip_cliente(self) -> str:
        if self.confia_proxy:
            adelante = self.headers.get("X-Forwarded-For") or ""
            primera = adelante.split(",")[0].strip()
            if primera:
                return primera
            real = (self.headers.get("X-Real-IP") or "").strip()
            if real:
                return real
        return self.client_address[0]

    def _origen_cors(self) -> str | None:
        """Valor que debe llevar ``Access-Control-Allow-Origin``, o None."""
        if not self.origenes:
            return None
        origen = (self.headers.get("Origin") or "").strip().rstrip("/")
        if "*" in self.origenes:
            return origen or "*"
        return origen if origen and origen in self.origenes else None

    def _cabeceras_cors(self) -> None:
        origen = self._origen_cors()
        if not origen:
            return
        self.send_header("Access-Control-Allow-Origin", origen)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Expose-Headers", "Content-Type")

    def _responder(self, codigo: int, datos: dict[str, Any], cerrar: bool = False) -> None:
        cuerpo = json.dumps(datos, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self._cabeceras_cors()
        if cerrar or self.close_connection:
            self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _error(self, codigo: int, mensaje: str, tipo: str = "invalid_request_error") -> None:
        """Responde un error y cierra la conexión.

        Con HTTP/1.1 y keep-alive, si abortamos sin leer el cuerpo del POST,
        esos bytes quedan en el socket y la siguiente lectura los toma como
        una petición nueva (y devuelve un 400 en HTML). Drenamos lo que quede
        y cerramos: el cliente recibe exactamente un JSON limpio.

        El cuerpo lleva ``error`` como texto (formato histórico de Moon Light) y
        ``error_openai`` con la forma que esperan los clientes estilo OpenAI.
        """
        self._drenar_cuerpo()
        self.close_connection = True
        self._responder(codigo, {
            "error": mensaje,
            "error_openai": {"message": mensaje, "type": tipo, "code": int(codigo)},
        }, cerrar=True)

    def _drenar_cuerpo(self) -> None:
        """Consume el cuerpo pendiente para no contaminar la conexión."""
        if getattr(self, "_cuerpo_leido", False):
            return
        self._cuerpo_leido = True
        try:
            longitud = int(self.headers.get("Content-Length") or 0)
        except (ValueError, AttributeError):
            return
        restante = min(longitud, MAX_CUERPO)
        while restante > 0:
            trozo = self.rfile.read(min(restante, 65536))
            if not trozo:
                break
            restante -= len(trozo)

    def _autorizado(self) -> bool:
        if self.token is None:
            return True                      # servidor abierto (ya avisado al arrancar)
        recibido = ""
        cabecera = self.headers.get("Authorization", "")
        if cabecera.lower().startswith("bearer "):
            recibido = cabecera[7:].strip()
        if not recibido:
            recibido = (self.headers.get("X-Moon-Token") or "").strip()
        return bool(recibido) and hmac.compare_digest(recibido, self.token)

    def _leer_json(self) -> dict[str, Any] | None:
        try:
            longitud = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            self._error(HTTPStatus.BAD_REQUEST, "Content-Length inválido.")
            return None
        if longitud <= 0:
            self._error(HTTPStatus.BAD_REQUEST, "El cuerpo de la petición está vacío.")
            return None
        if longitud > MAX_CUERPO:
            self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Petición demasiado grande.")
            return None
        bruto = self.rfile.read(longitud)
        self._cuerpo_leido = True
        try:
            cargado = json.loads(bruto.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._error(HTTPStatus.BAD_REQUEST, "El cuerpo debe ser JSON válido en UTF-8.")
            return None
        if not isinstance(cargado, dict):
            self._error(HTTPStatus.BAD_REQUEST, "Se esperaba un objeto JSON.")
            return None
        return cargado

    # ------------------------------------------------------- eventos (SSE)

    def _abrir_sse(self) -> None:
        self.close_connection = True
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Accel-Buffering", "no")   # que nginx no acumule
        self._cabeceras_cors()
        self.send_header("Connection", "close")
        self.end_headers()

    def _evento(self, datos: Any, evento: str | None = None) -> bool:
        """Escribe un evento SSE. Devuelve False si el cliente se fue."""
        cuerpo = datos if isinstance(datos, str) else json.dumps(datos, ensure_ascii=False)
        trozo = ""
        if evento:
            trozo += f"event: {evento}\n"
        for linea in cuerpo.split("\n"):
            trozo += f"data: {linea}\n"
        trozo += "\n"
        try:
            self.wfile.write(trozo.encode("utf-8"))
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError, OSError):
            log.info("El cliente cerró el flujo antes de terminar.")
            return False

    # ----------------------------------------------------------------- rutas

    def do_OPTIONS(self) -> None:  # noqa: N802 - lo exige BaseHTTPRequestHandler
        """Preflight de CORS y descubrimiento de métodos."""
        self._drenar_cuerpo()
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Content-Length", "0")
        self.send_header("Allow", "GET, POST, OPTIONS")
        origen = self._origen_cors()
        if origen:
            self.send_header("Access-Control-Allow-Origin", origen)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            pedidas = (self.headers.get("Access-Control-Request-Headers") or "").strip()
            self.send_header("Access-Control-Allow-Headers", pedidas or CABECERAS_CORS)
            self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        ruta = self.path.split("?", 1)[0].rstrip("/") or "/"

        if ruta == "/salud":
            self._responder(HTTPStatus.OK, {
                "servicio": NOMBRE,
                "version": VERSION,
                "modo": "local" if self.agente.config.modo_local else "modelo",
                "autenticacion": "token" if self.token else "ninguna",
                "cors": list(self.origenes) or "desactivado",
                "streaming": True,
                "compatible_openai": ["/v1/chat/completions", "/v1/models"],
                "modelo_expuesto": MODELO_EXPUESTO,
            })
            return

        if not self._autorizado():
            self._error(HTTPStatus.UNAUTHORIZED, "Token ausente o incorrecto.",
                        tipo="authentication_error")
            return

        if ruta == "/materias":
            self._responder(HTTPStatus.OK, {"materias": [
                {
                    "nombre": m.nombre,
                    "etiqueta": m.etiqueta,
                    "calculo_exacto": m.usa_calculo,
                    "plan": list(m.plan),
                }
                for m in MATERIAS
            ]})
            return

        if ruta == "/unidades":
            catalogo = {k: list(v) for k, v in units_tool.unidades_conocidas().items()}
            self._responder(HTTPStatus.OK, {"unidades": catalogo})
            return

        if ruta in ("/v1/models", "/models"):
            creado = int(time.time())
            self._responder(HTTPStatus.OK, {
                "object": "list",
                "data": [
                    {
                        "id": MODELO_EXPUESTO,
                        "object": "model",
                        "created": creado,
                        "owned_by": "moonlight",
                    },
                    *[
                        {
                            "id": f"{MODELO_EXPUESTO}:{m.nombre}",
                            "object": "model",
                            "created": creado,
                            "owned_by": "moonlight",
                        }
                        for m in MATERIAS
                    ],
                ],
            })
            return

        self._error(HTTPStatus.NOT_FOUND, f"Ruta desconocida: {ruta}", tipo="not_found")

    def do_POST(self) -> None:  # noqa: N802
        ruta = self.path.split("?", 1)[0].rstrip("/") or "/"

        if ruta == "/preguntar":
            manejar = self._preguntar
        elif ruta in ("/v1/chat/completions", "/chat/completions"):
            manejar = self._chat_completions
        else:
            self._error(HTTPStatus.NOT_FOUND, f"Ruta desconocida: {ruta}", tipo="not_found")
            return

        if not self._autorizado():
            self._error(HTTPStatus.UNAUTHORIZED, "Token ausente o incorrecto.",
                        tipo="authentication_error")
            return

        if not self.limitador.permite(self._ip_cliente()):
            self._error(HTTPStatus.TOO_MANY_REQUESTS,
                        "Demasiadas peticiones; espera un momento.",
                        tipo="rate_limit_error")
            return

        datos = self._leer_json()
        if datos is None:
            return
        manejar(datos)

    # --------------------------------------------------------- ruta propia

    def _preguntar(self, datos: dict[str, Any]) -> None:
        pregunta = datos.get("pregunta")
        if not isinstance(pregunta, str) or not pregunta.strip():
            self._error(HTTPStatus.BAD_REQUEST, "Falta el campo 'pregunta' (texto no vacío).")
            return
        if len(pregunta) > MAX_PREGUNTA:
            self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                        f"La pregunta supera {MAX_PREGUNTA} caracteres.")
            return

        materia = datos.get("materia")
        if materia is not None:
            if not isinstance(materia, str):
                self._error(HTTPStatus.BAD_REQUEST, "'materia' debe ser texto.")
                return
            if resolver_materia(materia) is None:
                self._error(HTTPStatus.BAD_REQUEST, f"Materia desconocida: '{materia}'.")
                return

        historial = self._leer_historial(datos.get("historial"))
        if historial is None:
            return

        if self._quiere_stream(datos):
            self._preguntar_en_flujo(pregunta, materia, historial)
            return

        try:
            respuesta = self._resolver(pregunta, materia, historial)
        except ErrorConfig as exc:
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, f"Configuración inválida: {exc}",
                        tipo="server_error")
            return

        self._responder(HTTPStatus.OK, self._cuerpo_respuesta(respuesta))

    def _preguntar_en_flujo(
        self, pregunta: str, materia: str | None, historial: list[Turno]
    ) -> None:
        self._abrir_sse()
        if not self._evento({"estado": "pensando"}, evento="estado"):
            return
        try:
            respuesta = self._resolver(pregunta, materia, historial)
        except ErrorConfig as exc:
            self._evento({"error": f"Configuración inválida: {exc}"}, evento="error")
            return

        meta = self._cuerpo_respuesta(respuesta)
        meta.pop("respuesta", None)
        if not self._evento(meta, evento="meta"):
            return
        for trozo in fragmentar(respuesta.texto):
            if not self._evento({"texto": trozo}, evento="fragmento"):
                return
        self._evento({"terminado": True}, evento="fin")
        self._evento("[DONE]")

    # ------------------------------------------------ compatible con OpenAI

    def _chat_completions(self, datos: dict[str, Any]) -> None:
        mensajes = datos.get("messages")
        if not isinstance(mensajes, list) or not mensajes:
            self._error(HTTPStatus.BAD_REQUEST, "Falta 'messages' (lista de mensajes).")
            return
        if len(mensajes) > MAX_MENSAJES:
            self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                        f"Demasiados mensajes (máximo {MAX_MENSAJES}).")
            return

        limpios: list[tuple[str, str]] = []
        for mensaje in mensajes:
            if not isinstance(mensaje, dict):
                self._error(HTTPStatus.BAD_REQUEST, "Cada mensaje debe ser un objeto JSON.")
                return
            rol = mensaje.get("role")
            if not isinstance(rol, str) or not rol:
                self._error(HTTPStatus.BAD_REQUEST, "Cada mensaje necesita 'role'.")
                return
            limpios.append((rol.lower(), texto_de_contenido(mensaje.get("content")).strip()))

        ultimas = [t for rol, t in limpios if rol == "user" and t]
        if not ultimas:
            self._error(HTTPStatus.BAD_REQUEST,
                        "No hay ningún mensaje de 'user' con contenido.")
            return
        pregunta = ultimas[-1]
        if len(pregunta) > MAX_PREGUNTA:
            self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                        f"El mensaje supera {MAX_PREGUNTA} caracteres.")
            return

        materia = self._materia_pedida(datos)
        if materia is False:                       # inválida: ya se contestó
            return

        historial = self._historial_de_mensajes(limpios)
        modelo = datos.get("model")
        modelo = modelo if isinstance(modelo, str) and modelo else MODELO_EXPUESTO

        if self._quiere_stream(datos):
            self._chat_en_flujo(pregunta, materia, historial, modelo)
            return

        try:
            respuesta = self._resolver(pregunta, materia, historial)
        except ErrorConfig as exc:
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, f"Configuración inválida: {exc}",
                        tipo="server_error")
            return

        self._responder(HTTPStatus.OK, {
            "id": self._identificador(),
            "object": "chat.completion",
            "created": int(time.time()),
            "model": modelo,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": respuesta.texto},
                "finish_reason": "stop",
            }],
            "usage": {
                "prompt_tokens": 0,
                "completion_tokens": respuesta.tokens,
                "total_tokens": respuesta.tokens,
            },
            "moonlight": self._extra(respuesta),
        })

    def _chat_en_flujo(
        self,
        pregunta: str,
        materia: str | None,
        historial: list[Turno],
        modelo: str,
    ) -> None:
        identificador = self._identificador()
        self._abrir_sse()
        try:
            respuesta = self._resolver(pregunta, materia, historial)
        except ErrorConfig as exc:
            self._evento({"error": {"message": f"Configuración inválida: {exc}",
                                    "type": "server_error"}})
            self._evento("[DONE]")
            return

        for trozo in self._trozos_openai(identificador, modelo, respuesta):
            if not self._evento(trozo):
                return
        self._evento("[DONE]")

    def _trozos_openai(self, identificador: str, modelo: str, respuesta: Any) -> Iterator[dict]:
        creado = int(time.time())

        def envoltorio(delta: dict[str, Any], fin: str | None = None) -> dict[str, Any]:
            return {
                "id": identificador,
                "object": "chat.completion.chunk",
                "created": creado,
                "model": modelo,
                "choices": [{"index": 0, "delta": delta, "finish_reason": fin}],
            }

        yield envoltorio({"role": "assistant", "content": ""})
        for trozo in fragmentar(respuesta.texto):
            yield envoltorio({"content": trozo})
        final = envoltorio({}, fin="stop")
        final["moonlight"] = self._extra(respuesta)
        yield final

    # ------------------------------------------------------------- interno

    @staticmethod
    def _identificador() -> str:
        return f"chatcmpl-{uuid.uuid4().hex[:24]}"

    @staticmethod
    def _quiere_stream(datos: dict[str, Any]) -> bool:
        valor = datos.get("stream")
        if isinstance(valor, str):
            return valor.strip().lower() in {"1", "true", "si", "sí", "yes"}
        return bool(valor)

    def _materia_pedida(self, datos: dict[str, Any]) -> str | None | bool:
        """Materia de un cuerpo estilo OpenAI: campo 'materia' o modelo 'moonlight:fisica'."""
        materia = datos.get("materia")
        if materia is None:
            modelo = datos.get("model")
            if isinstance(modelo, str) and ":" in modelo:
                materia = modelo.split(":", 1)[1].strip() or None
        if materia is None:
            return None
        if not isinstance(materia, str):
            self._error(HTTPStatus.BAD_REQUEST, "'materia' debe ser texto.")
            return False
        if resolver_materia(materia) is None:
            self._error(HTTPStatus.BAD_REQUEST, f"Materia desconocida: '{materia}'.")
            return False
        return materia

    def _leer_historial(self, bruto: Any) -> list[Turno] | None:
        """Historial opcional de /preguntar: lista de {pregunta, respuesta}."""
        if bruto is None:
            return []
        if not isinstance(bruto, list):
            self._error(HTTPStatus.BAD_REQUEST, "'historial' debe ser una lista.")
            return None
        turnos: list[Turno] = []
        for elemento in bruto[-MAX_MENSAJES:]:
            if not isinstance(elemento, dict):
                self._error(HTTPStatus.BAD_REQUEST,
                            "Cada elemento de 'historial' debe ser un objeto JSON.")
                return None
            pregunta = elemento.get("pregunta")
            respuesta = elemento.get("respuesta")
            if not isinstance(pregunta, str) or not isinstance(respuesta, str):
                self._error(HTTPStatus.BAD_REQUEST,
                            "Cada turno del historial necesita 'pregunta' y 'respuesta' de texto.")
                return None
            turnos.append(Turno(pregunta[:MAX_PREGUNTA], respuesta[:MAX_PREGUNTA]))
        return turnos

    @staticmethod
    def _historial_de_mensajes(limpios: list[tuple[str, str]]) -> list[Turno]:
        """Empareja los mensajes previos (todos menos la última pregunta) en turnos."""
        pares: list[Turno] = []
        pendiente: str | None = None
        # Se descarta la última intervención del usuario: es la pregunta actual.
        indices_usuario = [i for i, (rol, t) in enumerate(limpios) if rol == "user" and t]
        corte = indices_usuario[-1] if indices_usuario else len(limpios)
        for rol, texto in limpios[:corte]:
            if not texto:
                continue
            if rol == "user":
                pendiente = texto
            elif rol == "assistant" and pendiente is not None:
                pares.append(Turno(pendiente, texto))
                pendiente = None
        return pares

    def _resolver(self, pregunta: str, materia: str | None, historial: list[Turno]):
        """Ejecuta el agente del hilo con el historial recibido (sin estado compartido)."""
        agente = self.agente
        limite = max(0, agente.config.memoria_max_turnos)
        agente.memoria = list(historial)[-limite:] if limite else []
        try:
            return agente.responder(pregunta, materia_forzada=materia)
        finally:
            agente.reiniciar()

    @staticmethod
    def _extra(respuesta: Any) -> dict[str, Any]:
        return {
            "materia": respuesta.materia,
            "confianza": respuesta.confianza,
            "origen": respuesta.origen,
            "herramientas": list(respuesta.herramientas),
            "avisos": list(respuesta.avisos),
            "ruta": respuesta.explicacion_ruta,
            "segundos": round(respuesta.segundos, 3),
        }

    def _cuerpo_respuesta(self, respuesta: Any) -> dict[str, Any]:
        return {
            "respuesta": respuesta.texto,
            "materia": respuesta.materia,
            "confianza": respuesta.confianza,
            "origen": respuesta.origen,
            "herramientas": list(respuesta.herramientas),
            "avisos": list(respuesta.avisos),
            "ruta": respuesta.explicacion_ruta,
            "tokens": respuesta.tokens,
            "segundos": round(respuesta.segundos, 3),
        }


def crear_servidor(
    host: str = "127.0.0.1",
    puerto: int = 8080,
    config: Config | None = None,
    permitir_sin_token: bool = False,
    cert: str | None = None,
    clave: str | None = None,
) -> ThreadingHTTPServer:
    """Construye el servidor sin arrancarlo (útil también para pruebas).

    Si no hay token y `host` no es local, se niega a arrancar salvo que se pase
    `permitir_sin_token=True`. Con `cert` (y opcionalmente `clave`) el socket se
    envuelve en TLS y el servicio pasa a ser HTTPS.
    """
    token = token_configurado()
    es_local = host in {"127.0.0.1", "localhost", "::1"}
    if token is None and not es_local and not permitir_sin_token:
        raise ErrorConfig(
            f"Sin {VAR_TOKEN} definido el servidor quedaría SIN AUTENTICACIÓN y "
            f"accesible desde la red en '{host}'. Define el token o usa --insegura "
            "si de verdad es lo que quieres."
        )
    if clave and not cert:
        raise ErrorConfig("Diste la clave TLS pero no el certificado (--cert).")

    base = config or Config()

    class Manejador(ManejadorMoonLight):
        pass

    Manejador.fabrica_agente = staticmethod(lambda: AgenteMoonLight(base))
    Manejador.limitador = Limitador()
    Manejador.token = token
    Manejador.origenes = origenes_configurados()
    Manejador.confia_proxy = confia_en_proxy()
    Manejador.almacen_hilo = threading.local()

    servidor = ThreadingHTTPServer((host, puerto), Manejador)
    servidor.daemon_threads = True

    if cert:
        try:
            contexto = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            contexto.minimum_version = ssl.TLSVersion.TLSv1_2
            contexto.load_cert_chain(certfile=cert, keyfile=clave)
        except (OSError, ssl.SSLError) as exc:
            servidor.server_close()
            raise ErrorConfig(f"No pude cargar el certificado TLS: {exc}") from exc
        servidor.socket = contexto.wrap_socket(servidor.socket, server_side=True)

    return servidor


def servir(
    host: str = "127.0.0.1",
    puerto: int = 8080,
    config: Config | None = None,
    permitir_sin_token: bool = False,
    cert: str | None = None,
    clave: str | None = None,
) -> int:
    """Arranca el servidor hasta que se interrumpa con Ctrl+C."""
    servidor = crear_servidor(host, puerto, config, permitir_sin_token, cert, clave)
    token = token_configurado()
    esquema = "https" if cert else "http"

    print(f"{NOMBRE} {VERSION} escuchando en {esquema}://{host}:{puerto}")
    if token:
        print(f"Autenticación activa: envía 'Authorization: Bearer <{VAR_TOKEN}>'.")
    else:
        print(
            "\n⚠ AVISO DE SEGURIDAD: no hay token, el servidor está SIN AUTENTICACIÓN.\n"
            f"  Cualquiera que alcance este puerto puede usarlo (y gastar tu credencial\n"
            f"  del modelo). Define {VAR_TOKEN} antes de exponerlo fuera de tu máquina.\n"
        )
    origenes = origenes_configurados()
    print(f"CORS: {', '.join(origenes) if origenes else 'desactivado'}"
          f"  ({VAR_CORS} para cambiarlo)")
    if not cert:
        print("Sin TLS: usa --cert/--clave o un proxy inverso si sale de la máquina.")
    print("Prueba: POST /preguntar con {\"pregunta\": \"deriva x^2\"}")
    print(f"Clientes estilo OpenAI: POST /v1/chat/completions (modelo '{MODELO_EXPUESTO}').")

    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
    finally:
        servidor.server_close()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="moonlight-api",
        description=f"Servidor HTTP de {NOMBRE} (sin dependencias externas).",
    )
    parser.add_argument("--host", default="127.0.0.1", help="interfaz de escucha")
    parser.add_argument("--puerto", type=int, default=8080, help="puerto TCP")
    parser.add_argument("--insegura", action="store_true",
                        help=f"permite escuchar fuera de localhost sin {VAR_TOKEN} (no recomendado)")
    parser.add_argument("--cert", help="certificado TLS en PEM (activa HTTPS)")
    parser.add_argument("--clave", help="clave privada TLS (si no va dentro del certificado)")
    parser.add_argument("--cors", help="orígenes permitidos: '*' o lista separada por comas")
    parser.add_argument("-v", "--verbose", action="count", default=0, help="más registro")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.WARNING if args.verbose == 0 else (
            logging.INFO if args.verbose == 1 else logging.DEBUG
        ),
        format="%(levelname)s %(name)s: %(message)s",
    )

    if args.cors:
        os.environ[VAR_CORS] = args.cors

    try:
        return servir(args.host, args.puerto, permitir_sin_token=args.insegura,
                      cert=args.cert, clave=args.clave)
    except ErrorConfig as exc:
        print(f"No arranco: {exc}")
        return 1
    except OSError as exc:
        print(f"No pude abrir el puerto {args.puerto}: {exc}")
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
