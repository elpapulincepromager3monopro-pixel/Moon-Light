# Moon Light

Tutor de estudio por consola y API, escrito en español. Resuelve dudas de
matemáticas y conversión de unidades sin depender de ningún servicio externo,
y puede apoyarse en un modelo de lenguaje cuando hay uno disponible.

Requiere Python 3.10 o superior.

## Instalación

Como paquete (deja las órdenes `moonlight` y `moonlight-api` en la consola):

```bash
pip install -e ".[dev]"
```

O solo las dependencias, para ejecutarlo desde la carpeta del proyecto:

```bash
pip install -r requirements.txt
```

Copia `.env.ejemplo` a `.env` para tener a mano todas las variables de entorno
con su explicación. Moon Light no lee ese archivo por su cuenta; cárgalo con tu
herramienta habitual (`set -a && . ./.env && set +a`).

## Uso por consola

```bash
moonlight "deriva x^3"
moonlight "convierte 5 km a millas"
moonlight --materia matematicas "resuelve 2x + 4 = 10"
```

Sin instalar el paquete, lo mismo con `python -m moonlight "deriva x^3"`.
Sin pregunta arranca una sesión interactiva.

## Modelo de lenguaje (opcional)

Sin credencial, Moon Light funciona en modo local: sigue calculando con SymPy
y convirtiendo unidades. Para respuestas explicativas más ricas:

- `MOONLIGHT_API_KEY`: credencial del proveedor compatible con OpenAI.
- `MOONLIGHT_BASE_URL`: URL base alternativa (Ollama, LM Studio, etc.). Con una
  URL local no hace falta credencial.
- `MOONLIGHT_MODELO`: nombre del modelo.

## API HTTP

```bash
moonlight-api --puerto 8000     # o: python -m moonlight.api --puerto 8000
```

Rutas propias:

| Ruta | Qué hace |
| --- | --- |
| `GET /salud` | estado, modo y capacidades (no exige token) |
| `GET /materias` | materias disponibles |
| `GET /unidades` | catálogo de unidades convertibles |
| `POST /preguntar` | `{"pregunta": "...", "materia": "matematicas", "historial": [...], "stream": false}` |

Rutas compatibles con el dialecto de OpenAI (para clientes como el agente
Hermes, Open WebUI, LangChain o el SDK oficial apuntado a otra URL base):

| Ruta | Qué hace |
| --- | --- |
| `GET /v1/models` | lista `moonlight` y un modelo por materia (`moonlight:fisica`) |
| `POST /v1/chat/completions` | `{"model": "...", "messages": [...], "stream": true}` |

Elegir materia desde un cliente que solo sabe mandar `model`: usa
`moonlight:<materia>`, por ejemplo `moonlight:matematicas`.

### Conectar el agente Hermes

```bash
export MOONLIGHT_API_TOKEN="un-token-largo-y-aleatorio"
moonlight-api --puerto 8000
```

En Hermes (o cualquier cliente estilo OpenAI): URL base
`http://127.0.0.1:8000/v1`, clave de API el mismo token, modelo `moonlight`.

### Respuestas en streaming

Con `"stream": true` la respuesta llega como *Server-Sent Events*. En
`/preguntar` los eventos son `estado`, `meta`, `fragmento`, `fin` y `[DONE]`;
en `/v1/chat/completions` son trozos `chat.completion.chunk` y `[DONE]`, tal
como espera un cliente de OpenAI. El tutor calcula la respuesta completa y la
entrega por partes, así que el texto aparece progresivamente aunque no venga
palabra por palabra del modelo.

### Conversaciones

El servidor no guarda estado: el contexto viaja en cada petición (`historial`
en `/preguntar`, `messages` en la ruta compatible). Así varias personas pueden
usar la misma instancia sin mezclar conversaciones, y las peticiones se
atienden en paralelo (un agente por hilo).

### Seguridad

- Si no defines `MOONLIGHT_API_TOKEN`, el servidor queda **sin autenticación** y
  cualquiera que alcance el puerto podrá usarlo (y gastar tu credencial del
  modelo). Sin token solo se permite escuchar en `127.0.0.1`; para exponerlo
  hace falta el token o `--insegura`.
- Token en `Authorization: Bearer <token>` o `X-Moon-Token`.
- HTTPS directo con `--cert certificado.pem --clave clave.pem`, o bien detrás de
  un proxy inverso que termine TLS.
- CORS desactivado por defecto. Actívalo con `MOONLIGHT_CORS="*"` o una lista de
  orígenes separados por comas (`--cors` hace lo mismo). Incluye respuesta al
  preflight `OPTIONS`.
- Detrás de un proxy, `MOONLIGHT_CONFIA_PROXY=1` hace que el limitador use
  `X-Forwarded-For`. No lo actives si el puerto es alcanzable en directo: esa
  cabecera se puede falsificar.
- Hay límite de tamaño de cuerpo (128 KB) y un limitador por IP; suficiente para
  uso personal, no para producción abierta.

## Límites de cálculo

Cada operación simbólica tiene plazo (`MOONLIGHT_LIMITE_CALCULO`, 8 s por
defecto) y se respeta también cuando la petición llega por HTTP: en ese caso el
cálculo se hace en un proceso aparte que se puede cortar de verdad. Los
cálculos aislados simultáneos se limitan con `MOONLIGHT_MAX_PROCESOS_CALCULO`
(4 por defecto); si se llena el cupo, la petición responde con un error claro
en lugar de esperar sin fin.

## Pruebas

```bash
python -m pytest -q
```

172 pruebas, sin red y sin servicios externos.

## Estructura

- `moonlight/config.py` — configuración y variables de entorno.
- `moonlight/subjects.py` — catálogo de materias.
- `moonlight/router.py` — decide la materia de cada pregunta.
- `moonlight/llm.py` — cliente del modelo de lenguaje.
- `moonlight/agent.py` — orquesta herramientas y modelo.
- `moonlight/cli.py`, `moonlight/api.py` — interfaces.
- `moonlight/tools/` — cálculo simbólico y unidades.

## Licencia

MIT. Ver el archivo `LICENSE`.
